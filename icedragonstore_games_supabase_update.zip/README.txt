ICEDRAGONSTORE Bottom Navigation - smooth transition update

Perubahan:
- Tab Card dibuang.
- Navigasi bawah: Home, Wheel, Shop, History.
- Butang back automatik pada halaman tab sekunder dibuang.
- Animasi kiri/kanan diganti dengan fade ringkas 160ms supaya pertukaran tab kurang mengganggu.
- Ikon notifikasi kekal di bahagian atas.
- Fail main.dart dan page lain dikekalkan dari pakej sebelum ini.

Pemasangan:
1. Buat backup fail semasa.
2. Ekstrak ZIP di root projek Flutter.
3. Jalankan flutter analyze.
4. Jika lulus, jalankan flutter build apk --release.

Nota:
Animasi ini mengubah peralihan route sahaja. Jika mahu mengekalkan keadaan tab tanpa memuat semula data, struktur navigasi perlu ditukar kepada IndexedStack atau router berasaskan tab.

Skeleton loading:
- Skeleton shimmer ditambah untuk muatan awal halaman Shop, Wheel, History dan Wallet.
- Widget boleh guna semula berada di lib/widgets/skeleton_loading.dart.
- Spinner kecil untuk proses tindakan seperti pembelian/tuntutan dikekalkan.

Build APK melalui GitHub Actions:
- Fail workflow: .github/workflows/build-apk.yml
- Jika repository menyimpan ZIP, gunakan nama tepat icedragonstore_app_no_shop_promo5s.zip pada root repository.
- Jalankan Actions > Build ICEDRAGONSTORE APK > Run workflow.
- APK release tersedia sebagai artifact bernama icedragonstore-release-apk.
