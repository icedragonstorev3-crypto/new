# ICEDRAGONSTORE APK update 1.0.1+2

## Updates
- Guest users can spin the wheel through `secure_spin_guest`; logged-in users continue using `secure_spin_with_auth`.
- ICE CASH rewards are filtered from the wheel list in fresh data and cached data only; the wallet/shop implementation is not removed.
- Wheel prize redemption is routed to WhatsApp, without asking for Game ID or Zone ID in the wheel claim flow.
- Wheel WhatsApp redemption uses `601135268529`.
- Wheel history uses `wheel_recent_history` for the 10 latest public records and `lookup_wheel_tracking` for exact searches. The list displays the masked tracking ID returned by SQL; exact search shows the full tracking ID.
- Shop guests can view the product catalog and only see WhatsApp checkout. The account-balance payment option is shown only to signed-in users.
- App version incremented to `1.0.1+2`.

## Backend requirements
This APK expects the corresponding Supabase SQL functions/policies to already be installed:
- `secure_spin_guest(text)`
- `wheel_recent_history(integer)`
- `lookup_wheel_tracking(text)`

The SQL-side reward-code creation change (recipient phone required) must be installed in the admin/web interface's database RPC; this Flutter project does not contain an admin reward-code creation screen.

## Validation note
The source changes were reviewed and patched, but a Flutter build/analyzer could not be run in this environment because the Flutter/Dart executables are not installed here. Build and test with your configured Flutter SDK before installing the APK.


## 1.0.2+3 — History carian kod spin
- History awam menunjukkan kod spin sahaja (hasil daripada RPC wheel_recent_history).
- Carian menggunakan kod spin melalui RPC lookup_wheel_tracking.
- Hasil carian menunjukkan tarikh sahaja, telefon tersamar, dan tracking penuh tersembunyi sehingga ikon mata ditekan.
- Tambah butang salin tracking dan aliran tuntutan WhatsApp.
- Modal kemenangan: tracking tersembunyi secara lalai, butang lihat/sembunyi dan salin.
