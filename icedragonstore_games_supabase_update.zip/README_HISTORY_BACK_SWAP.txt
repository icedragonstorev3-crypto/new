ICEDRAGONSTORE - History back button adjustment

Changes:
1. Shop purchase history (lib/pages/history_page.dart): hides the automatic AppBar back button.
2. Spin history (lib/pages/history_spin_page.dart): enables the automatic AppBar back button.

This relies on HistorySpinPage being opened with Navigator.push / a route stack so the back arrow can pop to the previous page.
Flutter analyze/build has not been run in this environment.
