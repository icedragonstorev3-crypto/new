import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseConfig {
  SupabaseConfig._();

  static const String url = 'https://pxiebgyruofgsublnspr.supabase.co';

  static const String anonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB4aWViZ3lydW9mZ3N1Ymxuc3ByIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU0OTM3NTMsImV4cCI6MjEwMTA2OTc1M30.urFw7ZxflxM0l3LVJS8a0jVGm5sJ5hOmte4iyUc8mMI';

  static Future<void> initialize() async {
    await Supabase.initialize(
      url: url,
      publishableKey: anonKey,
      authOptions: const FlutterAuthClientOptions(autoRefreshToken: true),
    );
  }

  static SupabaseClient get client => Supabase.instance.client;
}
