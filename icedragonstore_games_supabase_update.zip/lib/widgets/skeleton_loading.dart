import 'package:flutter/material.dart';

/// Skeleton layout used while remote page data is being fetched.
/// A single animation controller drives every placeholder to avoid creating
/// one ticker per skeleton block.
enum SkeletonType { shop, history, wallet, wheel }

class SkeletonLoading extends StatefulWidget {
  final SkeletonType type;

  const SkeletonLoading({super.key, required this.type});

  @override
  State<SkeletonLoading> createState() => _SkeletonLoadingState();
}

class _SkeletonLoadingState extends State<SkeletonLoading>
    with SingleTickerProviderStateMixin {
  late final AnimationController _shimmerController;

  static const Color _cardColor = Color(0xFF121A2D);
  static const Color _cardBorder = Color(0xFF202B43);

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1250),
    )..repeat();
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    super.dispose();
  }

  Widget _block({
    double width = double.infinity,
    required double height,
    double radius = 10,
  }) {
    return AnimatedBuilder(
      animation: _shimmerController,
      child: SizedBox(
        width: width,
        height: height,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(radius),
          ),
        ),
      ),
      builder: (context, child) {
        final shift = -1.25 + (_shimmerController.value * 2.5);
        return ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            begin: Alignment(shift, 0),
            end: Alignment(shift + 0.95, 0),
            colors: const [
              Color(0xFF1A2338),
              Color(0xFF34415D),
              Color(0xFF1A2338),
            ],
            stops: const [0.0, 0.5, 1.0],
          ).createShader(bounds),
          blendMode: BlendMode.srcATop,
          child: child,
        );
      },
    );
  }

  Widget _card({required Widget child, EdgeInsets padding = const EdgeInsets.all(14)}) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _cardBorder),
      ),
      child: child,
    );
  }

  Widget _productCard() {
    return _card(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _block(height: 100, radius: 12),
          const SizedBox(height: 12),
          _block(width: 82, height: 10, radius: 5),
          const SizedBox(height: 8),
          _block(height: 13, radius: 5),
          const SizedBox(height: 7),
          _block(width: 66, height: 13, radius: 5),
          const SizedBox(height: 12),
          _block(height: 34, radius: 10),
        ],
      ),
    );
  }

  List<Widget> _shopItems() => [
        Row(
          children: [
            Expanded(child: _block(width: double.infinity, height: 18, radius: 6)),
            const SizedBox(width: 12),
            _block(width: 74, height: 18, radius: 6),
          ],
        ),
        const SizedBox(height: 16),
        _card(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _block(width: 100, height: 11, radius: 5),
              const SizedBox(height: 12),
              _block(width: 155, height: 28, radius: 7),
              const SizedBox(height: 15),
              _block(height: 42, radius: 12),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _block(height: 45, radius: 13),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _block(height: 31, radius: 20)),
            const SizedBox(width: 8),
            Expanded(child: _block(height: 31, radius: 20)),
            const SizedBox(width: 8),
            Expanded(child: _block(height: 31, radius: 20)),
          ],
        ),
        const SizedBox(height: 18),
        GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.70,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: List<Widget>.generate(4, (_) => _productCard()),
        ),
      ];

  List<Widget> _historyItems() => [
        _block(width: 150, height: 18, radius: 6),
        const SizedBox(height: 16),
        ...List<Widget>.generate(4, (index) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _card(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _block(width: 46, height: 46, radius: 14),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _block(width: index.isEven ? 140 : 110, height: 13, radius: 5),
                        const SizedBox(height: 9),
                        _block(height: 10, radius: 5),
                        const SizedBox(height: 8),
                        _block(width: 95, height: 10, radius: 5),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  _block(width: 48, height: 20, radius: 7),
                ],
              ),
            ),
          );
        }),
      ];

  List<Widget> _walletItems() => [
        _card(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _block(width: 38, height: 38, radius: 12),
              const SizedBox(height: 17),
              _block(width: 112, height: 11, radius: 5),
              const SizedBox(height: 9),
              _block(width: 185, height: 31, radius: 7),
              const SizedBox(height: 18),
              _block(height: 36, radius: 10),
            ],
          ),
        ),
        const SizedBox(height: 18),
        _block(width: 170, height: 17, radius: 6),
        const SizedBox(height: 12),
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _block(height: 44, radius: 11),
              const SizedBox(height: 12),
              _block(height: 44, radius: 11),
              const SizedBox(height: 12),
              _block(height: 46, radius: 11),
            ],
          ),
        ),
        const SizedBox(height: 22),
        _block(width: 155, height: 17, radius: 6),
        const SizedBox(height: 12),
        ...List<Widget>.generate(2, (_) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _card(
                child: Row(
                  children: [
                    _block(width: 40, height: 40, radius: 12),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _block(width: 120, height: 12, radius: 5),
                          const SizedBox(height: 8),
                          _block(width: 86, height: 10, radius: 5),
                        ],
                      ),
                    ),
                    _block(width: 62, height: 18, radius: 6),
                  ],
                ),
              ),
            )),
      ];

  List<Widget> _wheelItems() => [
        _block(width: 125, height: 17, radius: 6),
        const SizedBox(height: 24),
        Center(child: _block(width: 246, height: 246, radius: 123)),
        const SizedBox(height: 25),
        Row(
          children: [
            Expanded(child: _block(height: 48, radius: 14)),
            const SizedBox(width: 12),
            Expanded(child: _block(height: 48, radius: 14)),
          ],
        ),
        const SizedBox(height: 20),
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _block(width: 130, height: 14, radius: 5),
              const SizedBox(height: 13),
              _block(height: 11, radius: 5),
              const SizedBox(height: 8),
              _block(width: 205, height: 11, radius: 5),
              const SizedBox(height: 15),
              _block(height: 42, radius: 11),
            ],
          ),
        ),
      ];

  List<Widget> _itemsForType() {
    switch (widget.type) {
      case SkeletonType.shop:
        return _shopItems();
      case SkeletonType.history:
        return _historyItems();
      case SkeletonType.wallet:
        return _walletItems();
      case SkeletonType.wheel:
        return _wheelItems();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Memuatkan kandungan',
      liveRegion: true,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
        children: _itemsForType(),
      ),
    );
  }
}
