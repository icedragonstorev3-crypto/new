import 'dart:async';
import 'package:flutter/material.dart';

/// Toast global yang muncul di bahagian atas skrin.
class TopToast {
  static OverlayEntry? _activeEntry;
  static Timer? _timer;

  static void show(
    BuildContext context,
    String message, {
    bool error = false,
    Duration duration = const Duration(milliseconds: 2800),
  }) {
    final overlay = Overlay.maybeOf(context, rootOverlay: true);
    if (overlay == null || message.trim().isEmpty) return;

    _timer?.cancel();
    _activeEntry?.remove();
    _activeEntry = null;

    final color = error ? const Color(0xFFDC2626) : const Color(0xFF059669);
    late final OverlayEntry entry;
    entry = OverlayEntry(
      builder: (overlayContext) => Positioned(
        top: MediaQuery.of(overlayContext).padding.top + 10,
        left: 16,
        right: 16,
        child: SafeArea(
          bottom: false,
          child: Material(
            color: Colors.transparent,
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: -14, end: 0),
              duration: const Duration(milliseconds: 180),
              curve: Curves.easeOutCubic,
              builder: (context, dy, child) => Transform.translate(
                offset: Offset(0, dy),
                child: child,
              ),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xFF17191D),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: color.withValues(alpha: .7)),
                  boxShadow: const [
                    BoxShadow(color: Colors.black26, blurRadius: 16, offset: Offset(0, 5)),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  child: Row(
                    children: [
                      Icon(error ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded,
                          color: color, size: 22),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(message, style: const TextStyle(color: Colors.white, fontSize: 13.5)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
    _activeEntry = entry;
    overlay.insert(entry);
    _timer = Timer(duration, () {
      if (_activeEntry == entry) {
        entry.remove();
        _activeEntry = null;
      }
    });
  }
}
