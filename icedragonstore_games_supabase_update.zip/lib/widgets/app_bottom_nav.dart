import 'package:flutter/material.dart';

import '../pages/wheel_page.dart';

import 'top_toast.dart';

/// Navigasi utama: Home dan Wheel. Sejarah pesanan dibuka melalui Home.
/// Halaman Shop tidak lagi dipaparkan dalam navigasi utama.
class AppBottomNav extends StatelessWidget {
  final int currentIndex;

  const AppBottomNav({super.key, required this.currentIndex});

  static const Color _orange = Color(0xFFFF6A2A);
  static const Color _background = Color(0xFF111214);

  void _go(BuildContext context, int index) {
    if (index == currentIndex) return;

    // Home ialah halaman utama yang berada di bawah stack navigasi.
    if (index == 0) {
      Navigator.of(context).popUntil((route) => route.isFirst);
      return;
    }

    final Widget page = switch (index) {
      1 => const WheelPage(),
      _ => const SizedBox.shrink(),
    };

    Navigator.of(context).pushAndRemoveUntil<void>(
      PageRouteBuilder<void>(
        pageBuilder: (context, animation, secondaryAnimation) => page,
        transitionDuration: const Duration(milliseconds: 160),
        reverseTransitionDuration: const Duration(milliseconds: 140),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOut,
            reverseCurve: Curves.easeIn,
          );
          return FadeTransition(
            opacity: curved,
            child: child,
          );
        },
      ),
      (route) => route.isFirst,
    );
  }

  @override
  Widget build(BuildContext context) {
    const items = <({IconData icon, String label})>[
      (icon: Icons.home_rounded, label: 'Home'),
      (icon: Icons.casino_outlined, label: 'Wheel'),
    ];

    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 7),
        decoration: BoxDecoration(
          color: _background,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.white.withValues(alpha: .08)),
          boxShadow: const [
            BoxShadow(
              color: Colors.black45,
              blurRadius: 18,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          children: List.generate(items.length, (index) {
            final item = items[index];
            final selected = index == currentIndex;
            return Expanded(
              child: Semantics(
                button: true,
                selected: selected,
                label: item.label,
                child: InkWell(
                  borderRadius: BorderRadius.circular(15),
                  onTap: () => _go(context, index),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          item.icon,
                          size: 22,
                          color: selected ? _orange : Colors.white54,
                        ),
                        const SizedBox(height: 3),
                        Text(
                          item.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: selected
                                ? FontWeight.w800
                                : FontWeight.w500,
                            color: selected ? Colors.white : Colors.white54,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

/// Ikon notifikasi berada di bahagian atas halaman.
Widget notificationAction(BuildContext context) {
  return IconButton(
    tooltip: 'Notifikasi',
    onPressed: () {
      TopToast.show(context, 'Pusat notifikasi belum disambungkan.');
    },
    icon: const Icon(Icons.notifications_none_rounded),
  );
}
