import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../widgets/top_toast.dart';
import '../widgets/skeleton_loading.dart';
import '../services/safe_cache_service.dart';
// GANTIKAN dengan nombor WhatsApp bisnes dalam format antarabangsa tanpa +, contoh 60123456789.
const String shopWhatsAppNumber = '601135268529';

class ShopPage extends StatefulWidget {
  final String? gameCode;
  final String? gameName;
  final String? gameDescription;
  const ShopPage({super.key, this.gameCode, this.gameName, this.gameDescription});

  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  final SupabaseClient client = Supabase.instance.client;

  final TextEditingController _gameUserIdController = TextEditingController();
  final TextEditingController _voucherController = TextEditingController();


  List<Map<String, dynamic>> products = [];
  List<Map<String, dynamic>> orders = [];

  Map<String, dynamic>? selectedProduct;

  double balance = 0;
  int quantity = 1;

  bool loading = true;
  bool buying = false;
  bool voucherApplied = false;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  @override
  void dispose() {
    _gameUserIdController.dispose();
    _voucherController.dispose();
    super.dispose();
  }

  double _number(dynamic value) {
    if (value == null) return 0;

    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value.toString()) ?? 0;
  }

  String _money(dynamic value) {
    return _number(value).toStringAsFixed(2);
  }

  String _string(dynamic value) {
    return value?.toString() ?? '';
  }

  void _message(String message, {bool error = false}) {
    if (!mounted) return;
    TopToast.show(context, message, error: error);
  }

  Future<void> _requireSession() async {
    final session = client.auth.currentSession;

    if (session == null) {
      throw Exception('Sila log masuk terlebih dahulu.');
    }

    final linkResult = await client.rpc('link_my_auth_account');

    if (linkResult is Map) {
      final success = linkResult['success'];

      if (success == false) {
        throw Exception(
          linkResult['message']?.toString() ?? 'Akaun belum dipautkan.',
        );
      }
    }

    try {
      final profile = await client.rpc('get_my_profile');

      if (profile is Map) {
        if (profile['success'] == false) {
          throw Exception(
            profile['message']?.toString() ?? 'Profil tidak dijumpai.',
          );
        }

        if (profile['is_banned'] == true) {
          throw Exception('Akaun anda telah disekat.');
        }
      }
    } catch (_) {
      // Jika RPC profile tidak diperlukan oleh backend shop,
      // teruskan menggunakan session.
    }
  }

  Future<void> _loadBalance() async {
    final result = await client.rpc('rm_wallet_my_balance');

    if (result is Map) {
      balance = _number(result['balance'] ?? result['rm_balance']);
    } else if (result is num) {
      balance = result.toDouble();
    }
  }

  Future<void> _loadProducts() async {
    final userId = client.auth.currentUser?.id;
    try {
      final result = await client.rpc('rm_shop_public_products')
          .timeout(const Duration(seconds: 15));
      if (result is List) {
        products = result.whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item)).toList();
        if (userId != null) {
          await SafeCacheService.instance.writeList(
            userId: userId, bucket: 'rm_shop_products', data: products);
        }
      } else {
        products = [];
      }
    } catch (_) {
      // Paparan produk sahaja boleh guna cache. Pembelian tetap perlu online.
      if (userId != null) {
        products = await SafeCacheService.instance.readList(
              userId: userId, bucket: 'rm_shop_products') ?? <Map<String, dynamic>>[];
      } else {
        products = [];
      }
    }
  }

  bool get _isGamePackagePage =>
      (widget.gameCode ?? '').trim().isNotEmpty;

  List<Map<String, dynamic>> get _visibleProducts {
    final code = widget.gameCode?.trim().toUpperCase();
    if (code == null || code.isEmpty) return products;

    // Halaman game hanya memaparkan pakej milik game yang dipilih.
    return products.where((p) {
      final productCode = _string(p['game_code']).trim().toUpperCase();
      final productType = _string(p['product_type']).trim().toUpperCase();
      final sameGame = productCode == code;
      final isTopup = productType.isEmpty || productType == 'GAME_TOPUP';
      return sameGame && isTopup;
    }).toList();
  }

  Future<void> _loadOrders() async {
    final result = await client.rpc('rm_shop_my_orders');

    if (result is List) {
      orders = result
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    } else {
      orders = [];
    }
  }

  Future<void> _loadAll() async {
    if (mounted) {
      setState(() {
        loading = true;
      });
    }

    try {
      if (client.auth.currentSession != null) {
        await _requireSession();
        await Future.wait([_loadBalance(), _loadProducts(), _loadOrders()]);
      } else {
        // Tetamu dibenarkan melihat katalog sahaja; tiada baki/pesanan akaun.
        balance = 0;
        orders = [];
        await _loadProducts();
      }
    } catch (e) {
      _message(_cleanError(e), error: true);
    }

    if (!mounted) return;

    setState(() {
      loading = false;
    });
  }

  String _cleanError(Object error) {
    final text = error.toString();

    if (text.startsWith('Exception: ')) {
      return text.substring(11);
    }

    if (text.contains('RM_SHOP_NOT_READY')) {
      return 'Sistem pembelian RM belum dipasang. Jalankan SQL RM Shop dahulu.';
    }

    if (text.contains('GAME_USER_ID_REQUIRED')) {
      return 'User ID game diperlukan.';
    }

    if (text.contains('GAME_USER_ID_TOO_LONG')) {
      return 'User ID game terlalu panjang.';
    }

    if (text.contains('INSUFFICIENT_RM_BALANCE')) {
      return 'Baki RM tidak mencukupi.';
    }

    if (text.contains('INSUFFICIENT_STOCK')) {
      return 'Stok produk tidak mencukupi.';
    }

    if (text.contains('VOUCHER_INVALID')) {
      return 'Kod voucher tidak sah atau tidak aktif.';
    }

    if (text.contains('VOUCHER_NOT_STARTED')) {
      return 'Voucher belum mula digunakan.';
    }

    if (text.contains('VOUCHER_EXPIRED')) {
      return 'Voucher telah tamat tempoh.';
    }

    if (text.contains('VOUCHER_USAGE_LIMIT_REACHED')) {
      return 'Had penggunaan voucher telah dicapai.';
    }

    if (text.contains('VOUCHER_MIN_SPEND_NOT_MET')) {
      return 'Jumlah pembelian belum mencapai belanja minimum voucher.';
    }

    if (text.contains('RM_PRICE_NOT_CONFIGURED')) {
      return 'Harga RM produk belum ditetapkan oleh admin.';
    }

    if (text.contains('PRODUCT_NOT_FOUND_OR_INACTIVE')) {
      return 'Produk tidak dijumpai atau sudah tidak aktif.';
    }

    if (text.contains('AUTH_REQUIRED')) {
      return 'Sila log masuk terlebih dahulu.';
    }

    if (text.contains('SYSTEM_USER_NOT_FOUND')) {
      return 'Akaun pengguna tidak dijumpai.';
    }

    return text
        .replaceFirst('PostgrestException(message: ', '')
        .replaceFirst('Exception: ', '');
  }

  void _openBuy(Map<String, dynamic> product) {
    final stock = _number(product['stock']).toInt();

    if (stock <= 0) {
      _message('Produk ini sudah habis.', error: true);
      return;
    }

    _gameUserIdController.clear();
    _voucherController.clear();
    voucherApplied = false;

    setState(() {
      selectedProduct = product;
      quantity = 1;
    });

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, modalSetState) {
            final productData = selectedProduct;

            if (productData == null) {
              return const SizedBox.shrink();
            }

            final price = _number(productData['price_rm']);

            final currentStock = _number(productData['stock']).toInt();

            final total = price * quantity;

            return Padding(
              padding: EdgeInsets.only(
                left: 12,
                right: 12,
                top: 12,
                bottom: MediaQuery.of(context).viewInsets.bottom + 12,
              ),
              child: Material(
                color: const Color(0xFF11182B),
                borderRadius: BorderRadius.circular(26),
                clipBehavior: Clip.antiAlias,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              _string(productData['name']),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: const Icon(
                              Icons.close_rounded,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 4),

                      if (_string(productData['description']).isNotEmpty)
                        Text(
                          _string(productData['description']),
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 12,
                          ),
                        ),

                      const SizedBox(height: 18),

                      const Text(
                        'USER ID GAME',
                        style: TextStyle(
                          color: Colors.amber,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),

                      const SizedBox(height: 7),

                      TextField(
                        controller: _gameUserIdController,
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.done,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                        ),
                        decoration: InputDecoration(
                          hintText: 'Masukkan User ID game',
                          hintStyle: const TextStyle(color: Colors.white38),
                          prefixIcon: const Icon(
                            Icons.person_rounded,
                            color: Colors.amber,
                          ),
                          filled: true,
                          fillColor: const Color(0xFF080D1C),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: const BorderSide(color: Colors.white12),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: const BorderSide(color: Colors.white12),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: const BorderSide(color: Colors.amber),
                          ),
                        ),
                      ),

                      const SizedBox(height: 16),

                      const Text(
                        'KOD VOUCHER',
                        style: TextStyle(
                          color: Colors.amber,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 7),
                      TextField(
                        controller: _voucherController,
                        textCapitalization: TextCapitalization.characters,
                        autocorrect: false,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                        decoration: InputDecoration(
                          hintText: 'Masukkan kod voucher (pilihan)',
                          hintStyle: const TextStyle(color: Colors.white38),
                          prefixIcon: const Icon(Icons.local_offer_rounded, color: Colors.amber),
                          filled: true,
                          fillColor: const Color(0xFF080D1C),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Colors.white12)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Colors.white12)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Colors.amber)),
                        ),
                        onChanged: (_) {
                          if (voucherApplied) {
                            modalSetState(() => voucherApplied = false);
                          }
                        },
                      ),
                      const SizedBox(height: 8),
                      SizedBox(width: double.infinity, child: OutlinedButton.icon(
                        onPressed: buying ? null : () {
                          final code = _voucherController.text.trim();
                          if (code.isEmpty) {
                            modalSetState(() => voucherApplied = false);
                            _message('Masukkan kod voucher atau biarkan kosong jika tidak mahu guna voucher.');
                            return;
                          }
                          modalSetState(() => voucherApplied = true);
                          _message('Kod voucher dipilih. Kelayakan dan diskaun sebenar disahkan server semasa pembelian.');
                        },
                        icon: Icon(voucherApplied ? Icons.check_circle : Icons.local_offer_outlined),
                        label: Text(voucherApplied ? 'VOUCHER DIGUNAKAN' : 'APPLY VOUCHER'),
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.amber, side: const BorderSide(color: Colors.amber), padding: const EdgeInsets.symmetric(vertical: 13)),
                      )),
                      const SizedBox(height: 16),

                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF080D1C),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: .07),
                          ),
                        ),
                        child: Column(
                          children: [
                            _summaryRow('Harga seunit', 'RM ${_money(price)}'),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'Kuantiti',
                                  style: TextStyle(
                                    color: Colors.white54,
                                    fontSize: 12,
                                  ),
                                ),
                                Row(
                                  children: [
                                    _quantityButton(
                                      icon: Icons.remove,
                                      onPressed: quantity > 1
                                          ? () {
                                              modalSetState(() {
                                                quantity--;
                                              });
                                            }
                                          : null,
                                    ),
                                    SizedBox(
                                      width: 42,
                                      child: Center(
                                        child: Text(
                                          '$quantity',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ),
                                    ),
                                    _quantityButton(
                                      icon: Icons.add,
                                      onPressed: quantity < currentStock
                                          ? () {
                                              modalSetState(() {
                                                quantity++;
                                              });
                                            }
                                          : null,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            const Divider(color: Colors.white12, height: 24),
                            _summaryRow(
                              'Subtotal',
                              'RM ${_money(total)}',
                            ),
                            if (_voucherController.text.trim().isNotEmpty) ...[
                              const SizedBox(height: 8),
                              _summaryRow(
                                'Voucher',
                                voucherApplied ? 'Dipilih — disahkan semasa bayar' : 'Tiada voucher digunakan',
                                small: true,
                              ),
                            ],
                            const SizedBox(height: 8),
                            const Text(
                              'Diskaun dan jumlah akhir akan disahkan oleh server semasa pembelian.',
                              style: TextStyle(color: Colors.white38, fontSize: 10),
                            ),
                            const SizedBox(height: 6),
                            _summaryRow(
                              'Baki maksimum selepas pembelian',
                              'RM ${_money(balance - total)}',
                              small: true,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 16),

                      // Pilihan pembayaran: WhatsApp untuk pengesahan manual,
                      // atau baki akaun RM untuk pembelian terus oleh pengguna log masuk.
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: buying ? null : () async => _payViaWhatsApp(modalSetState),
                          icon: const Icon(Icons.chat, size: 19),
                          label: Text(
                            buying ? 'SEDANG MEMPROSES...' : 'BAYAR MELALUI WHATSAPP',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF25D366),
                            foregroundColor: Colors.white,
                            disabledBackgroundColor: Colors.white12,
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                          ),
                        ),
                      ),
                      // Tetamu hanya dibenarkan membuat pesanan melalui WhatsApp.
                      // Pembayaran baki akaun hanya dipaparkan kepada pengguna log masuk.
                      if (client.auth.currentSession != null) ...[
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: buying ? null : () async => _buyProduct(modalSetState),
                            icon: const Icon(Icons.account_balance_wallet, size: 19),
                            label: Text(
                              'BAYAR GUNA BAKI AKAUN • RM ${_money(balance)}',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontWeight: FontWeight.w900),
                            ),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.amber,
                              side: const BorderSide(color: Colors.amber),
                              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                            ),
                          ),
                        ),
                      ],

                      const SizedBox(height: 4),

                      const Center(
                        child: Text(
                          'Pastikan User ID game betul sebelum membuat pembelian.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white38, fontSize: 10),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _summaryRow(
    String title,
    String value, {
    bool highlight = false,
    bool small = false,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(color: Colors.white54, fontSize: small ? 10 : 12),
        ),
        Text(
          value,
          style: TextStyle(
            color: highlight ? const Color(0xFFFFB000) : Colors.white,
            fontSize: highlight ? 16 : 12,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget _quantityButton({
    required IconData icon,
    required VoidCallback? onPressed,
  }) {
    return Material(
      color: Colors.white.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(10),
        child: SizedBox(
          width: 36,
          height: 36,
          child: Icon(
            icon,
            size: 18,
            color: onPressed == null ? Colors.white24 : Colors.white,
          ),
        ),
      ),
    );
  }

  Future<void> _payViaWhatsApp(StateSetter modalSetState) async {
    final product = selectedProduct;
    if (product == null) return;
    final gameUserId = _gameUserIdController.text.trim();
    if (gameUserId.isEmpty) {
      _message('Sila masukkan User ID game.', error: true);
      return;
    }
    if (gameUserId.length > 100) {
      _message('User ID game terlalu panjang.', error: true);
      return;
    }
    final stock = _number(product['stock']).toInt();
    if (stock <= 0 || quantity > stock) {
      _message(stock <= 0 ? 'Produk ini sudah habis.' : 'Kuantiti melebihi stok.', error: true);
      return;
    }
    if (shopWhatsAppNumber.contains('X') || shopWhatsAppNumber.trim().isEmpty) {
      _message('Nombor WhatsApp kedai belum ditetapkan. Tetapkan shopWhatsAppNumber dalam shop_page.dart.', error: true);
      return;
    }
    final name = _string(product['name']);
    final price = _number(product['price_rm']);
    final total = price * quantity;
    final gameName = widget.gameName ?? 'Game';
    final message = <String>[
      'Assalamualaikum ICEDRAGONSTORE, saya ingin membuat pesanan melalui WhatsApp.',
      '',
      'Produk: $name',
      'Game: $gameName',
      'Game User ID: $gameUserId',
      'Kuantiti: $quantity',
      'Harga seunit: RM ${_money(price)}',
      'Jumlah anggaran: RM ${_money(total)}',
      'Status: Menunggu pengesahan admin',
      '',
      'Saya pengguna ${client.auth.currentSession == null ? 'tetamu' : 'berdaftar'}. Sila sahkan stok, jumlah akhir dan kaedah pembayaran.'
    ].join('\n');
    modalSetState(() => buying = true);
    try {
      final uri = Uri.parse('https://wa.me/${shopWhatsAppNumber.trim()}?text=${Uri.encodeComponent(message)}');
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened) throw Exception('WhatsApp tidak dapat dibuka. Pastikan WhatsApp atau browser tersedia.');
      if (mounted) {
        Navigator.of(context).pop();
        _message('Pesanan dibuka di WhatsApp. Pesanan belum disahkan sehingga admin membalas.');
      }
    } catch (e) {
      if (mounted) _message('Gagal membuka WhatsApp: ${_cleanError(e)}', error: true);
    } finally {
      if (mounted) modalSetState(() => buying = false);
    }
  }

  Future<void> _buyProduct(StateSetter modalSetState) async {
    final product = selectedProduct;

    if (product == null) return;

    final gameUserId = _gameUserIdController.text.trim();

    if (gameUserId.isEmpty) {
      _message('Sila masukkan User ID game.', error: true);
      return;
    }

    if (gameUserId.length > 100) {
      _message('User ID game terlalu panjang.', error: true);
      return;
    }

    final stock = _number(product['stock']).toInt();

    if (stock <= 0) {
      _message('Produk ini sudah habis.', error: true);
      return;
    }

    if (quantity > stock) {
      _message('Kuantiti melebihi stok.', error: true);
      return;
    }

    final price = _number(product['price_rm']);
    final total = price * quantity;
    final voucherCode = voucherApplied ? _voucherController.text.trim().toUpperCase() : '';

    // Local balance is only an estimate; the backend checks the final amount
    // after validating and calculating any voucher discount atomically.
    if (voucherCode.isEmpty && balance < total) {
      _message('Baki RM tidak mencukupi.', error: true);
      return;
    }

    modalSetState(() {
      buying = true;
    });

    try {
      await _requireSession();
      final result = await client.rpc(
        'rm_shop_buy',
        params: {
          'p_product_id': product['id'],
          'p_quantity': quantity,
          'p_game_user_id': gameUserId,
          'p_voucher_code': voucherCode.isEmpty ? null : voucherCode,
        },
      );

      if (result is Map && result['success'] == false) {
        throw Exception(result['message']?.toString() ?? 'Pembelian gagal.');
      }

      if (!mounted) return;

      Navigator.of(context).pop();
      final receipt = <String, dynamic>{
        if (result is Map) ...Map<String, dynamic>.from(result),
        'product_name': result is Map ? _string(result['product_name']) : _string(product['name']),
        'product_id': product['id'], 'unit_price_rm': price, 'quantity': quantity,
        'subtotal_rm': result is Map ? _number(result['subtotal_rm'] ?? result['subtotal']) : total,
        'game_user_id': gameUserId,
        'voucher_code': result is Map ? _string(result['voucher_code']) : '',
        'discount_rm': result is Map ? _number(result['discount_rm']) : 0.0,
        'total_rm': result is Map ? _number(result['total_rm']) : total,
        'tracking_number': result is Map ? _string(result['tracking_number']) : '',
        'status': result is Map ? _string(result['status']) : 'success',
        'created_at': result is Map ? _string(result['created_at']) : DateTime.now().toIso8601String(),
      };
      if (!mounted) return;
      await Navigator.of(this.context).push(MaterialPageRoute<void>(
        builder: (_) => ShopPurchaseReceiptPage(receipt: receipt),
      ));
      await _loadAll();
    } catch (e) {
      if (mounted) {
        _message(_cleanError(e), error: true);
      }
    } finally {
      if (mounted) {
        modalSetState(() {
          buying = false;
        });
      }
    }
  }

  Widget _productCard(Map<String, dynamic> product) {
    final name = _string(product['name']);

    final description = _string(product['description']);

    final price = _number(product['price_rm']);

    final stock = _number(product['stock']).toInt();

    final image = _string(product['image_url']);

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: stock > 0
            ? () => _openBuy(product)
            : () {
                _message('Produk ini sudah habis.', error: true);
              },
        borderRadius: BorderRadius.circular(18),
        child: Ink(
          decoration: BoxDecoration(
            color: const Color(0xFF11182B),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withValues(alpha: .07)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 1,
                child: image.isNotEmpty
                    ? Image.network(
                        image,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => _imagePlaceholder(),
                      )
                    : _imagePlaceholder(),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    if (description.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: Text(
                          description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    const SizedBox(height: 9),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'RM ${_money(price)}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Color(0xFFFFB000),
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          stock > 0 ? 'Stok $stock' : 'HABIS',
                          style: TextStyle(
                            color: stock > 0
                                ? Colors.greenAccent
                                : Colors.redAccent,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 9),
                    SizedBox(
                      width: double.infinity,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: stock > 0
                              ? const Color(0xFFFFB000)
                              : Colors.white.withValues(alpha: .06),
                          borderRadius: BorderRadius.circular(11),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 9),
                          child: Center(
                            child: Text(
                              stock > 0 ? 'BELI' : 'STOK HABIS',
                              style: TextStyle(
                                color: stock > 0
                                    ? const Color(0xFF111111)
                                    : Colors.white38,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _imagePlaceholder() {
    return Container(
      color: const Color(0xFF080D1C),
      alignment: Alignment.center,
      child: const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.white24,
        size: 38,
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final productName = _string(order['product_name']);

    final tracking = _string(order['tracking_number']);

    final gameUserId = _string(order['game_user_id']);

    final status = _string(order['status']);

    final quantity = _number(order['quantity']).toInt();

    final total = _number(order['total_rm']);

    final createdAt = _string(order['created_at']);

    return Material(
      color: const Color(0xFF11182B),
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: const Color(0xFFFFB000).withValues(alpha: .10),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.inventory_2_rounded,
                color: Color(0xFFFFB000),
                size: 21,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    productName.isEmpty ? 'Produk' : productName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  if (gameUserId.isNotEmpty)
                    Text(
                      'User ID: $gameUserId',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 10,
                      ),
                    ),
                  if (tracking.isNotEmpty)
                    Text(
                      'Tracking: $tracking',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white38,
                        fontSize: 9,
                      ),
                    ),
                  const SizedBox(height: 4),
                  Text(
                    '$quantity unit • $createdAt',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white30, fontSize: 9),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'RM ${_money(total)}',
                  style: const TextStyle(
                    color: Color(0xFFFFB000),
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  status.isEmpty ? '-' : status,
                  style: const TextStyle(
                    color: Colors.greenAccent,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredProducts = _visibleProducts;

    return Scaffold(
      backgroundColor: const Color(0xFF070B19),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(tooltip: 'Kembali', icon: const Icon(Icons.arrow_back_rounded), onPressed: () { if (Navigator.of(context).canPop()) Navigator.of(context).pop(); }),
        backgroundColor: const Color(0xFF070B19),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ICEDRAGONSTORE',
              style: TextStyle(
                color: Color(0xFFFFD166),
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            Text(
              widget.gameName == null ? 'SHOP RM' : widget.gameName!,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
            ),
          ],
        ),
        actions: [
          if (client.auth.currentSession != null)
            Padding(
              padding: const EdgeInsets.only(right: 2),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF151C30),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Text(
                    'RM ${_money(balance)}',
                    style: const TextStyle(
                      color: Color(0xFFFFD166),
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
          IconButton(
            tooltip: 'Notifikasi',
            onPressed: () => _message('Pusat notifikasi belum disambungkan.'),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: const Color(0xFFFFB000),
        backgroundColor: const Color(0xFF11182B),
        onRefresh: _loadAll,
        child: loading
            ? const SkeletonLoading(type: SkeletonType.shop)
            : ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 30),
                children: [
                  if (_isGamePackagePage && _string(widget.gameDescription).trim().isNotEmpty) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(15),
                      margin: const EdgeInsets.only(bottom: 18),
                      decoration: BoxDecoration(
                        color: const Color(0xFF141C31),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white.withValues(alpha: .08)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFB000).withValues(alpha: .13),
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: const Icon(Icons.videogame_asset_rounded, color: Color(0xFFFFB000)),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.gameName ?? 'Maklumat Game',
                                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  widget.gameDescription!.trim(),
                                  style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.4),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 4),

                  Text(
                    _isGamePackagePage ? 'SENARAI PAKEJ ${widget.gameName ?? ''}'.trim() : 'SHOP ITEM',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                  ),

                  const SizedBox(height: 4),

                  Text(
                    _isGamePackagePage
                        ? 'Pilih pakej untuk game ${widget.gameName ?? ''} sahaja.'
                        : 'Pilih pakej yang tersedia untuk meneruskan pembelian.',
                    style: const TextStyle(color: Colors.white38, fontSize: 11),
                  ),

                  const SizedBox(height: 12),

                  if (filteredProducts.isEmpty)
                    Container(
                      padding: const EdgeInsets.all(35),
                      decoration: BoxDecoration(
                        color: const Color(0xFF11182B),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Column(
                        children: [
                          Icon(
                            Icons.inventory_2_outlined,
                            color: Colors.white24,
                            size: 42,
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Produk belum tersedia untuk game ini.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final width = constraints.maxWidth;

                        final columns = width >= 700 ? 4 : 2;

                        return GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: filteredProducts.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: columns,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10,
                                childAspectRatio: columns == 2 ? .70 : .72,
                              ),
                          itemBuilder: (context, index) {
                            return _productCard(filteredProducts[index]);
                          },
                        );
                      },
                    ),

                  if (!_isGamePackagePage) ...[
                  const SizedBox(height: 28),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'PESANAN SAYA',
                        style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      IconButton(
                        onPressed: _loadAll,
                        icon: const Icon(
                          Icons.refresh_rounded,
                          color: Colors.white54,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 8),

                  if (orders.isEmpty)
                    Container(
                      padding: const EdgeInsets.all(30),
                      decoration: BoxDecoration(
                        color: const Color(0xFF11182B),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Text(
                        'Belum ada pesanan.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white38, fontSize: 11),
                      ),
                    )
                  else
                    ...orders.map(
                      (order) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: _orderCard(order),
                      ),
                    ),
                  ],
                ],
              ),
      ),
    );
  }

  Widget _statBox(String title, String value, Color valueColor) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .16),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: .06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white38,
              fontSize: 8,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: valueColor,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}


class ShopPurchaseReceiptPage extends StatelessWidget {
  final Map<String, dynamic> receipt;
  const ShopPurchaseReceiptPage({super.key, required this.receipt});
  String _text(String key, [String fallback = '—']) { final v = receipt[key]?.toString().trim() ?? ''; return v.isEmpty ? fallback : v; }
  double _num(String key) { final v = receipt[key]; if (v is num) return v.toDouble(); return double.tryParse(v?.toString() ?? '') ?? 0; }
  String _rm(double n) => 'RM ${n.toStringAsFixed(2)}';
  @override Widget build(BuildContext context) {
    final subtotal = _num('subtotal_rm'), discount = _num('discount_rm'), total = _num('total_rm');
    return Scaffold(backgroundColor: const Color(0xFF080D1C), appBar: AppBar(title: const Text('Resit Pembelian'), backgroundColor: const Color(0xFF11182B), automaticallyImplyLeading: false),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
        const SizedBox(height: 12), const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 68),
        const SizedBox(height: 10), const Text('PEMBELIAN SELESAI', textAlign: TextAlign.center, style: TextStyle(color: Colors.greenAccent, fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 22),
        _section('MAKLUMAT PESANAN', [ _row('Nama produk', _text('product_name')), _row('Tracking', _text('tracking_number')), _row('Status pesanan', _text('status', 'Berjaya')), _row('Tarikh pembelian', _text('created_at')), _row('User ID game', _text('game_user_id')), _row('Kuantiti', _text('quantity', '1')) ]),
        const SizedBox(height: 14),
        _section('PECAHAN BAYARAN', [ _row('Harga seunit', _rm(_num('unit_price_rm'))), _row('Subtotal sebelum diskaun', _rm(subtotal)), _row('Kod voucher', _text('voucher_code', 'Tiada')), _row('Diskaun voucher ditolak', '- ${_rm(discount)}', color: Colors.greenAccent), const Divider(color: Colors.white12, height: 24), _row('JUMLAH DIBAYAR', _rm(total), color: Colors.amber, bold: true) ]),
        const SizedBox(height: 12), const Text('Diskaun dan jumlah akhir berdasarkan respons server. Jika tiada voucher digunakan, diskaun ialah RM 0.00.', style: TextStyle(color: Colors.white38, fontSize: 11)),
        const SizedBox(height: 24), SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.storefront_rounded), label: const Text('KEMBALI KE KEDAI'), style: ElevatedButton.styleFrom(backgroundColor: Colors.amber, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 15))))
      ])));
  }
  Widget _section(String title, List<Widget> children) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF11182B), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.amber, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 12), ...children]));
  Widget _row(String label, String value, {Color? color, bool bold = false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 5, child: Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12))), const SizedBox(width: 12), Expanded(flex: 5, child: Text(value, textAlign: TextAlign.end, style: TextStyle(color: color ?? Colors.white, fontSize: 12, fontWeight: bold ? FontWeight.w900 : FontWeight.w700)))]));
}
