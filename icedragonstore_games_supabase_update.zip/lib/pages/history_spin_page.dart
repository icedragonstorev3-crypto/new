import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config/supabase_config.dart';
import '../widgets/skeleton_loading.dart';

const String _wheelWhatsAppNumber = '601135268529';

class HistorySpinPage extends StatefulWidget {
  const HistorySpinPage({super.key});

  @override
  State<HistorySpinPage> createState() => _HistorySpinPageState();
}

class _HistorySpinPageState extends State<HistorySpinPage> {
  final SupabaseClient client = SupabaseConfig.client;
  final TextEditingController _spinCodeController = TextEditingController();

  List<Map<String, dynamic>> records = [];
  Map<String, dynamic>? searchedRecord;
  bool loading = true;
  bool searching = false;
  bool trackingVisible = false;
  String? errorMessage;
  String? searchMessage;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  @override
  void dispose() {
    _spinCodeController.dispose();
    super.dispose();
  }

  String _text(dynamic value, [String fallback = '-']) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty || text == 'null' ? fallback : text;
  }

  // Kenal pasti ZONK daripada data sebenar Supabase (nama hadiah "no luck"),
  // walaupun rekod lama masih mempunyai status PENDING dan tracking_number.
  bool _isZonkRecord(Map<String, dynamic> record) {
    final status = _text(record['status'], '').trim().toUpperCase();
    final rewardName = _text(record['reward_name'], '').trim().toLowerCase();
    final rewardType = _text(record['reward_type'] ?? record['type'], '').trim().toLowerCase();
    return status == 'ZONK' ||
        rewardType == 'zonk' ||
        rewardName == 'no luck' ||
        rewardName == 'zonk' ||
        rewardName.contains('zonk') ||
        rewardName.contains('tiada hadiah');
  }

  DateTime? _date(dynamic value) => DateTime.tryParse(value?.toString() ?? '');

  String _dateText(dynamic value) {
    final date = _date(value);
    if (date == null) return '-';
    final d = date.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    const months = ['Jan', 'Feb', 'Mac', 'Apr', 'Mei', 'Jun', 'Jul', 'Ogo', 'Sep', 'Okt', 'Nov', 'Dis'];
    return '${two(d.day)} ${months[d.month - 1]} ${d.year}';
  }

  Color _statusColor(String status) {
    final s = status.toLowerCase();
    if (s == 'zonk' || s.contains('cancel') || s.contains('fail') || s.contains('reject')) {
      return const Color(0xFFFF7373);
    }
    if (s.contains('success') || s.contains('complete') || s.contains('berjaya')) {
      return const Color(0xFF57D69A);
    }
    return const Color(0xFFFFC857);
  }

  Future<void> _loadHistory() async {
    if (mounted) {
      setState(() {
        loading = true;
        errorMessage = null;
        searchedRecord = null;
        trackingVisible = false;
      });
    }
    try {
      final response = await client
          .rpc('wheel_recent_history', params: {'p_limit': 10})
          .timeout(const Duration(seconds: 25));
      if (response is Map && response['success'] == false) {
        throw Exception(response['message']?.toString() ?? 'Gagal memuatkan sejarah roda.');
      }
      final raw = response is Map ? response['records'] : null;
      final loaded = raw is List
          ? raw
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .where((record) => !_isZonkRecord(record))
              .toList()
          : <Map<String, dynamic>>[];
      if (!mounted) return;
      setState(() {
        records = loaded;
        errorMessage = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => errorMessage = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _searchSpinCode() async {
    final code = _spinCodeController.text.trim().toUpperCase();
    if (code.isEmpty) {
      setState(() {
        searchedRecord = null;
        searchMessage = 'Masukkan kod spin untuk membuat carian.';
      });
      return;
    }
    setState(() {
      searching = true;
      searchedRecord = null;
      searchMessage = null;
      trackingVisible = false;
    });
    try {
      // RPC sedia ada menerima parameter p_tracking, tetapi nilainya ialah KOD SPIN.
      final response = await client
          .rpc('lookup_wheel_tracking', params: {'p_tracking': code})
          .timeout(const Duration(seconds: 25));
      if (response is! Map || response['success'] != true) {
        if (!mounted) return;
        setState(() {
          searchMessage = response is Map
              ? _text(response['message'], 'Kod spin tidak dijumpai.')
              : 'Respons carian tidak sah.';
        });
        return;
      }
      final raw = response['record'];
      if (raw is! Map) {
        if (mounted) setState(() => searchMessage = 'Rekod kod spin tidak sah.');
        return;
      }
      if (!mounted) return;
      setState(() {
        searchedRecord = Map<String, dynamic>.from(raw);
        searchMessage = null;
      });
    } catch (e) {
      if (mounted) setState(() => searchMessage = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => searching = false);
    }
  }

  Future<void> _copy(String value, String label) async {
    if (value.isEmpty || value == '-') return;
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$label disalin')),
    );
  }

  Future<void> _claimViaWhatsApp(Map<String, dynamic> record) async {
    final tracking = _text(record['tracking_number'], '');
    final reward = _text(record['reward_name'], 'Ganjaran');
    final spinCode = _text(record['spin_code'], '');
    if (tracking.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tracking tidak tersedia untuk rekod ini.')),
        );
      }
      return;
    }
    final message = Uri.encodeComponent(
      'Hai Admin ICEDRAGONSTORE,\n\n'
      'Saya ingin menebus ganjaran roda.\n'
      'Hadiah: $reward\n'
      'Kod spin: $spinCode\n'
      'Tracking ID: $tracking\n\n'
      'Sila bantu proses tuntutan saya. Terima kasih!',
    );
    final uri = Uri.parse('https://wa.me/$_wheelWhatsAppNumber?text=$message');
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('WhatsApp tidak dapat dibuka.'), backgroundColor: Colors.red),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('WhatsApp tidak dapat dibuka.'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Widget _trackingLine(String tracking) {
    return Row(
      children: [
        Expanded(
          child: Text(
            'Tracking: ${trackingVisible ? tracking : '••••••••••••'}',
            style: const TextStyle(color: Colors.white70, fontSize: 11, height: 1.4),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        IconButton(
          tooltip: trackingVisible ? 'Sembunyikan tracking' : 'Lihat tracking',
          visualDensity: VisualDensity.compact,
          onPressed: () => setState(() => trackingVisible = !trackingVisible),
          icon: Icon(trackingVisible ? Icons.visibility_off_rounded : Icons.visibility_rounded, size: 18, color: Colors.white70),
        ),
        IconButton(
          tooltip: 'Salin tracking',
          visualDensity: VisualDensity.compact,
          onPressed: () => _copy(tracking, 'Tracking'),
          icon: const Icon(Icons.copy_rounded, size: 17, color: Color(0xFF93C5FD)),
        ),
      ],
    );
  }

  Widget _recordCard(Map<String, dynamic> record, {required bool exactSearch}) {
    final spinCode = _text(record['spin_code']);
    final tracking = _text(record['tracking_number'], '');
    final reward = _text(record['reward_name'], 'Ganjaran');
    final status = _text(record['status'], 'PENDING');
    final date = record['date'] ?? record['created_at'];
    final phone = _text(record['phone'], 'Tidak tersedia');
    final isZonk = _isZonkRecord(record);
    final displayStatus = isZonk ? 'ZONK' : status;

    if (isZonk) {
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: const Color(0xFF11182B),
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: const Color(0x55FB7185)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.sentiment_dissatisfied_rounded, color: Color(0xFFFF7373), size: 25),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(reward, style: const TextStyle(color: Color(0xFFFFA3B1), fontSize: 14, fontWeight: FontWeight.w900)),
                const SizedBox(height: 5),
                Text('Kod spin: ${_text(record['spin_code'] ?? record['code_used'], '-')}', style: const TextStyle(color: Colors.white70, fontSize: 11, height: 1.4)),
              ])),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                decoration: BoxDecoration(color: const Color(0x22FB7185), borderRadius: BorderRadius.circular(30)),
                child: const Text('ZONK', style: TextStyle(color: Color(0xFFFFA3B1), fontSize: 9, fontWeight: FontWeight.w900)),
              ),
            ]),
            const SizedBox(height: 10),
            Text('Tarikh: ${_dateText(date)}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
            const SizedBox(height: 10),
            const Text('Tiada hadiah, sila cuba lagi :)', style: TextStyle(color: Colors.white, fontSize: 14)),
            const SizedBox(height: 5),
            const Text('Tiada tracking ID. Hadiah ini tidak boleh ditebus.', style: TextStyle(color: Colors.white38, fontSize: 11)),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF11182B),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.card_giftcard_rounded, color: Color(0xFFFFC857), size: 25),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(reward, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(
                exactSearch ? 'Kod spin: ${_text(record['spin_code'], '-')}'
                    : 'Kod spin: $spinCode',
                style: const TextStyle(color: Colors.white70, fontSize: 11, height: 1.4),
              ),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
              decoration: BoxDecoration(
                color: _statusColor(status).withValues(alpha: .13),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Text(displayStatus.toUpperCase(), style: TextStyle(color: _statusColor(displayStatus), fontSize: 9, fontWeight: FontWeight.w900)),
            ),
          ]),
          const SizedBox(height: 10),
          Text('Tarikh: ${_dateText(date)}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
          if (exactSearch) ...[
            const SizedBox(height: 5),
            Text('Telefon: $phone', style: const TextStyle(color: Colors.white54, fontSize: 11)),
            const SizedBox(height: 4),
            if (tracking.isNotEmpty) _trackingLine(tracking),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: OutlinedButton.icon(
                onPressed: tracking.isEmpty ? null : () => _copy(tracking, 'Tracking'),
                icon: const Icon(Icons.copy_rounded, size: 16),
                label: const Text('SALIN TRACKING'),
              )),
              if (!isZonk) ...[
                const SizedBox(width: 8),
                Expanded(child: ElevatedButton.icon(
                  onPressed: tracking.isEmpty ? null : () => _claimViaWhatsApp(record),
                  icon: const Icon(Icons.chat_rounded, size: 16),
                  label: const Text('WHATSAPP'),
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white),
                )),
              ],
            ]),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF070B19),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: const Color(0xFF070B19),
        foregroundColor: Colors.white,
        leading: IconButton(
          tooltip: 'Kembali',
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () {
            if (Navigator.of(context).canPop()) Navigator.of(context).pop();
          },
        ),
        title: const Text('SEJARAH TUNTUTAN', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
        actions: [IconButton(onPressed: loading ? null : _loadHistory, icon: const Icon(Icons.refresh_rounded))],
      ),
      body: loading
          ? const SkeletonLoading(type: SkeletonType.history)
          : RefreshIndicator(
              onRefresh: _loadHistory,
              color: const Color(0xFFFFB000),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                children: [
                  const Center(child: Icon(Icons.history_rounded, color: Color(0xFF6EE7B7), size: 25)),
                  const SizedBox(height: 8),
                  const Text('REKOD GANJARAN ANDA', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF6EE7B7), fontWeight: FontWeight.w900, letterSpacing: 1)),
                  const SizedBox(height: 7),
                  const Text('Rekod awam memaparkan kod spin tersamar. Masukkan kod spin untuk melihat maklumat tuntutan.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, fontSize: 12, height: 1.5)),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFF0D1326), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('CARI KOD SPIN', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w900, fontSize: 12)),
                      const SizedBox(height: 10),
                      Row(children: [
                        Expanded(child: TextField(
                          controller: _spinCodeController,
                          textCapitalization: TextCapitalization.characters,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                          decoration: InputDecoration(
                            hintText: 'Contoh kod spin: ICE-...',
                            hintStyle: const TextStyle(color: Colors.white38),
                            filled: true,
                            fillColor: const Color(0xFF11182B),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 13),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Colors.white12)),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: const BorderSide(color: Colors.white12)),
                          ),
                          onSubmitted: (_) => _searchSpinCode(),
                        )),
                        const SizedBox(width: 8),
                        SizedBox(height: 49, child: ElevatedButton(
                          onPressed: searching ? null : _searchSpinCode,
                          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2563EB), foregroundColor: Colors.white),
                          child: searching ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Cari'),
                        )),
                      ]),
                      if (searchMessage != null) ...[
                        const SizedBox(height: 10),
                        Text(searchMessage!, style: const TextStyle(color: Color(0xFFFDA4AF), fontSize: 12)),
                      ],
                      if (searchedRecord != null) ...[
                        const SizedBox(height: 14),
                        const Text('HASIL CARIAN — MAKLUMAT TUNTUTAN', style: TextStyle(color: Color(0xFF6EE7B7), fontWeight: FontWeight.w900, fontSize: 11)),
                        const SizedBox(height: 8),
                        _recordCard(searchedRecord!, exactSearch: true),
                      ],
                    ]),
                  ),
                  const SizedBox(height: 20),
                  Row(children: [
                    const Icon(Icons.list_alt_rounded, color: Color(0xFF60A5FA)),
                    const SizedBox(width: 8),
                    const Expanded(child: Text('10 REKOD TERDAHULU', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w900))),
                    Text('${records.length} rekod', style: const TextStyle(color: Colors.white38, fontSize: 11)),
                  ]),
                  const Divider(color: Colors.white12, height: 20),
                  if (errorMessage != null)
                    Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text(errorMessage!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFFDA4AF))))
                  else if (records.isEmpty)
                    const Padding(padding: EdgeInsets.symmetric(vertical: 35), child: Text('Belum ada rekod spin.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)))
                  else
                    ...records.map((record) => _recordCard(record, exactSearch: false)),
                ],
              ),
            ),
    );
  }
}
