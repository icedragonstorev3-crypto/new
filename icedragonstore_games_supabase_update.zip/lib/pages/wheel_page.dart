import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'history_spin_page.dart';
import '../widgets/app_bottom_nav.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/safe_cache_service.dart';
import '../widgets/skeleton_loading.dart';

class WheelPage extends StatefulWidget {
  const WheelPage({super.key});

  @override
  State<WheelPage> createState() => _WheelPageState();
}

class _WheelPageState extends State<WheelPage>
    with TickerProviderStateMixin {
  final SupabaseClient client = Supabase.instance.client;

  final TextEditingController rewardCodeController = TextEditingController();
  final TextEditingController gameIdController = TextEditingController();
  final TextEditingController zoneIdController = TextEditingController();

late final AnimationController _animationController;
late final AudioPlayer _wheelTickPlayer;

  // Audio tick diprate supaya tidak membebankan audio engine ketika wheel
  // melintasi banyak slice dalam masa yang sangat singkat.
  DateTime _lastSoundAt = DateTime.fromMillisecondsSinceEpoch(0);
  bool _soundCommandBusy = false;
  bool _wheelSoundReady = false;

  // Sound ON/OFF. Bila OFF, listener audio dibuang terus supaya animation
  // wheel tidak perlu mengira slice atau menghantar arahan audio setiap frame.
  bool _soundEnabled = true;

  static const Duration _minimumTickGap = Duration(milliseconds: 55);

  List<Map<String, dynamic>> prizes = [];
  Map<String, dynamic>? selectedPrize;
  Map<String, dynamic>? currentUser;

  bool loading = true;
  bool spinning = false;

  bool submittingClaim = false;

  // Kunci dalaman: menghalang _submitClaim dipanggil dua kali serentak.
  // Kunci ini kekal aktif sehingga permintaan asal benar-benar selesai,
  // walaupun UI timeout lebih awal. Perlindungan ini untuk satu instance app;
  // perlumbaan antara peranti perlu dikunci secara atomik di database.
  bool _claimRequestInFlight = false;

  double currentRotation = 0;
  double _animationStartRotation = 0;
  double _animationTargetRotation = 0;

  String trackingNumber = '';
  bool _winnerTrackingVisible = false;

int _lastSoundSlice = -1;

@override
void initState() {
  super.initState();

  _wheelTickPlayer = AudioPlayer();

  _animationController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 7200),
  );

  // Listener ini hanya mengira slice yang dilalui. Audio sebenar telah
  // dipre-load dan tidak lagi melakukan stop() + play() setiap tick.
  // Sound dihidupkan secara default. Bila user mute, listener ini akan
  // dibuang terus melalui _setSoundEnabled(false).
  _animationController.addListener(_handleWheelSound);

  _prepareWheelSound();
  _loadPrizes();
}

void _handleWheelSound() {
  // Safety guard tambahan. Dalam mode mute listener sepatutnya sudah
  // dibuang, jadi animation spin tidak membuat kerja audio langsung.
  if (!_soundEnabled || !mounted || !spinning || prizes.isEmpty) return;

  // Hadkan kerja pengiraan audio sebelum mengira easing dan kedudukan slice.
  // Jika terlalu rapat, semak semula pada frame seterusnya.
  final now = DateTime.now();
  if (now.difference(_lastSoundAt) < _minimumTickGap) return;

  final sliceAngle = (2 * math.pi) / prizes.length;

  final progress = Curves.easeOutQuart.transform(
    _animationController.value,
  );

  final rotation =
      _animationStartRotation +
          (_animationTargetRotation - _animationStartRotation) *
              progress;

  final currentSlice = (rotation / sliceAngle).floor();

  if (currentSlice == _lastSoundSlice) return;

  _lastSoundSlice = currentSlice;

  // Jangan hantar arahan audio terlalu rapat ketika wheel bergerak laju.
  _lastSoundAt = now;
  _playWheelTick();
}

Future<void> _prepareWheelSound() async {
  try {
    await _wheelTickPlayer.setReleaseMode(ReleaseMode.stop);
    await _wheelTickPlayer.setSource(
      AssetSource('audio/wheel_tick.wav'),
    );

    if (!mounted) return;
    _wheelSoundReady = true;
  } catch (e) {
    debugPrint('[WHEEL SOUND PRELOAD ERROR] $e');
  }
}

Future<void> _playWheelTick() async {
  if (!mounted || !spinning || !_wheelSoundReady) return;
  if (_soundCommandBusy) return;

  _soundCommandBusy = true;

  try {
    // Reuse source yang telah di-load. Ini jauh lebih ringan daripada
    // stop() + play(AssetSource(...)) untuk setiap slice.
    await _wheelTickPlayer.seek(Duration.zero);

    if (!mounted || !spinning) return;

    await _wheelTickPlayer.resume();
  } catch (e) {
    debugPrint('[WHEEL SOUND ERROR] $e');
  } finally {
    _soundCommandBusy = false;
  }
}

Future<void> _setSoundEnabled(bool enabled) async {
  if (_soundEnabled == enabled) return;

  if (mounted) {
    setState(() {
      _soundEnabled = enabled;
    });

    _toast(
      enabled ? 'Suara dibuka' : 'Suara ditutup',
    );
  } else {
    _soundEnabled = enabled;
  }

  if (!enabled) {
    // Ini bahagian penting untuk mode MUTE: buang listener supaya animation
    // controller tidak lagi memproses kiraan slice/audio ketika spin.
    _animationController.removeListener(_handleWheelSound);
    _soundCommandBusy = false;

    try {
      await _wheelTickPlayer.stop();
    } catch (e) {
      debugPrint('[WHEEL SOUND STOP ERROR] $e');
    }
  } else {
    // Sound ON: pasang semula listener hanya sekali.
    _animationController.removeListener(_handleWheelSound);
    _animationController.addListener(_handleWheelSound);

    if (!_wheelSoundReady) {
      await _prepareWheelSound();
    }
  }
}

@override
void dispose() {
  _animationController.removeListener(_handleWheelSound);
  _animationController.dispose();

  _wheelTickPlayer.dispose();

  rewardCodeController.dispose();
  gameIdController.dispose();
  zoneIdController.dispose();

  super.dispose();
}

String _string(dynamic value) => value?.toString() ?? '';

String _cleanError(Object error) {
  final text = error.toString();

  if (text.startsWith('Exception: ')) {
    return text.substring(11);
  }

  return text
      .replaceFirst('PostgrestException(message: ', '')
      .replaceFirst('Exception: ', '');
}

  void _toast(String message, {bool error = false}) {
    if (!mounted) return;

    // Toast muncul di bahagian atas, di bawah status bar.
    final overlay = Overlay.maybeOf(context);
    if (overlay == null) return;

    final entry = OverlayEntry(
      builder: (overlayContext) => Positioned(
        top: MediaQuery.of(overlayContext).padding.top + 12,
        left: 16,
        right: 16,
        child: SafeArea(
          bottom: false,
          child: Material(
            color: Colors.transparent,
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: 1),
              duration: const Duration(milliseconds: 180),
              curve: Curves.easeOutCubic,
              builder: (context, value, child) => Opacity(
                opacity: value,
                child: Transform.translate(
                  offset: Offset(0, -8 * (1 - value)),
                  child: child,
                ),
              ),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 13,
                ),
                decoration: BoxDecoration(
                  color: error
                      ? const Color(0xFFDC2626)
                      : const Color(0xFF059669),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 16,
                      offset: Offset(0, 5),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      error ? Icons.error_outline : Icons.check_circle_outline,
                      color: Colors.white,
                      size: 21,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        message,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );

    overlay.insert(entry);
    Future<void>.delayed(const Duration(milliseconds: 2800), () {
      if (entry.mounted) entry.remove();
    });
  }

  Future<void> _requireSession() async {
    final session = client.auth.currentSession;

    if (session == null) {
      throw Exception('Sila log masuk akaun terlebih dahulu.');
    }

    try {
      final linkResponse = await client.rpc('link_my_auth_account');

      if (linkResponse is Map && linkResponse['success'] == false) {
        throw Exception(
          linkResponse['message']?.toString() ??
              'Akaun Auth belum dipautkan.',
        );
      }
    } catch (e) {
      if (e.toString().contains('belum dipautkan') ||
          e.toString().contains('tidak dipautkan')) {
        rethrow;
      }
    }

    try {
      final profileResponse = await client.rpc('get_my_profile');

      if (profileResponse is Map) {
        final profile = Map<String, dynamic>.from(profileResponse);

        if (profile['success'] == false) {
          throw Exception(
            profile['message']?.toString() ?? 'Profil tidak dijumpai.',
          );
        }

        if (profile['is_banned'] == true ||
            (_string(profile['ban_reason']).trim().isNotEmpty)) {
          await SafeCacheService.instance.clearUser(client.auth.currentUser?.id ?? '');
        await client.auth.signOut();
          throw Exception('Akaun anda telah disekat oleh Admin.');
        }

        currentUser = profile;
      }
    } catch (e) {
      if (e.toString().contains('disekat') ||
          e.toString().contains('Profil tidak')) {
        rethrow;
      }

      // Kekalkan behavior laman asal:
      // roda masih boleh cuba menggunakan session Auth yang sah.
    }
  }

  Future<void> _loadPrizes() async {
    if (mounted) {
      setState(() => loading = true);
    }

    try {
      // Tetamu dan pengguna log masuk boleh melihat hadiah roda; spin tetamu menggunakan RPC khusus.
      if (client.auth.currentSession != null) {
        await _requireSession();
      }
      final userId = client.auth.currentUser?.id;
      final result = await client
          .from('wheel_rewards')
          .select('*')
          .order('position_index', ascending: true)
          .timeout(const Duration(seconds: 15));

      final loaded = result.whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .where((item) => item['is_hidden'] != true)
          // ICE CASH dikeluarkan daripada ganjaran roda sahaja.
          .where((item) => _requirement(item) != 'ice_cash')
          .toList();
      if (userId != null) {
        await SafeCacheService.instance.writeList(
          userId: userId, bucket: 'wheel_display', data: loaded);
      }
      if (mounted) setState(() => prizes = loaded);
    } catch (e) {
      final userId = client.auth.currentUser?.id;
      final cached = userId == null ? null :
          await SafeCacheService.instance.readList(
            userId: userId, bucket: 'wheel_display');
      if (cached != null && cached.isNotEmpty) {
        final safeCached = cached
            .where((item) => item['is_hidden'] != true)
            .where((item) => _requirement(item) != 'ice_cash')
            .toList();
        if (mounted) setState(() => prizes = safeCached);
        _toast('Paparan wheel menggunakan cache. Putaran roda masih memerlukan sambungan internet.');
      } else {
        _toast(_cleanError(e), error: true);
      }
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  Color _prizeColor(Map<String, dynamic> prize) {
    final raw = _string(prize['color']).trim();

    if (raw.startsWith('#')) {
      try {
        final hex = raw.substring(1);

        if (hex.length == 6) {
          return Color(int.parse('FF$hex', radix: 16));
        }

        if (hex.length == 8) {
          return Color(int.parse(hex, radix: 16));
        }
      } catch (_) {}
    }

    return const Color(0xFF334155);
  }

  String _prizeImage(Map<String, dynamic> prize) =>
      _string(prize['image_url']);

  String _prizeName(Map<String, dynamic> prize) {
    final name = _string(prize['name']).trim();
    return name.isEmpty ? 'Hadiah' : name;
  }

  String _requirement(Map<String, dynamic> prize) =>
      _string(prize['requirement_type']).trim().toLowerCase();

  bool _isIceCash(Map<String, dynamic> prize) =>
      _requirement(prize) == 'ice_cash';

  bool _isWhatsappOrTng(Map<String, dynamic> prize) {
    // Semua hadiah roda ditebus melalui WhatsApp; tiada Game ID atau Zone ID.
    return !_isIceCash(prize);
  }

  bool _needsGameId(Map<String, dynamic> prize) {
    final req = _requirement(prize);
    return req == 'game' || req == 'game_zone';
  }

  bool _needsZoneId(Map<String, dynamic> prize) =>
      _requirement(prize) == 'game_zone';

  bool _isZonk(Map<String, dynamic> prize, Map result) {
    final type = _string(result['type']).toLowerCase();
    final req = _requirement(prize);
    final name = _prizeName(prize).toLowerCase();
    final category = _string(prize['category']).toLowerCase();

    return type == 'zonk' ||
        req == 'zonk' ||
        category.contains('zonk') ||
        name.contains('zonk') ||
        name.contains('no luck') ||
        name.contains('cuba lagi') ||
        name.contains('kosong') ||
        name.contains('maaf');
  }

  /*
   * INI SENGAJA MENGIKUT VERSI index.html:
   *
   * secure_spin_with_auth({ p_code })
   *
   * BUKAN:
   * spin_the_wheel()
   * get_my_access_id()
   * access_id
   *
   * Server yang memilih reward sebenar.
   */

  int? _visualSlotFromRotation(double rotation, int totalItems) {
    if (!rotation.isFinite || totalItems <= 0) return null;
    final slice = 2 * math.pi / totalItems;
    var normalized = rotation % (2 * math.pi);
    if (normalized < 0) normalized += 2 * math.pi;
    var pointerAngle = (2 * math.pi - normalized) % (2 * math.pi);
    if (pointerAngle < 0) pointerAngle += 2 * math.pi;
    final slot = (pointerAngle / slice).floor();
    return slot >= 0 && slot < totalItems ? slot : null;
  }

  Future<void> _spin() async {
    if (spinning) return;

    FocusManager.instance.primaryFocus?.unfocus();

    final session = client.auth.currentSession;

    if (prizes.isEmpty) {
      _toast('Hadiah roda belum tersedia.', error: true);
      return;
    }

    final code = rewardCodeController.text.trim().toUpperCase();

    if (code.isEmpty) {
      _toast('Sila masukkan kod reward!', error: true);
      return;
    }

    setState(() {
      spinning = true;
      // Jangan bawa tracking tuntutan hadiah sebelumnya ke putaran baharu.
      trackingNumber = '';
      selectedPrize = null;
      submittingClaim = false;
    });

    try {
      // Tetamu menggunakan RPC khas; pengguna log masuk kekalkan RPC sedia ada.
      // RPC tetamu tetap mengesahkan kod dan stok di server.
      final rawResult = await client.rpc(
        session == null ? 'secure_spin_guest' : 'secure_spin_with_auth',
        params: {'p_code': code},
      );

      if (rawResult is! Map) {
        throw Exception('Respons spin tidak sah.');
      }

      final result = Map<String, dynamic>.from(rawResult);


      if (result['success'] != true) {
        throw Exception(
          result['message']?.toString() ?? 'Putaran gagal.',
        );
      }

      final rewardId = result['reward_id'];

      Map<String, dynamic>? winner;

      for (final prize in prizes) {
        if (_string(prize['id']) == _string(rewardId)) {
          winner = Map<String, dynamic>.from(prize);
          break;
        }
      }

      /*
       * Fallback sama seperti website.
       */
      winner ??= {
        'id': rewardId,
        'name': result['reward_name'] ??
            (_string(result['type']).toLowerCase() == 'zonk'
                ? 'ZONK'
                : 'Hadiah'),
        'image_url': result['image_url'] ?? '',
        'requirement_type': '',
        'category':
            _string(result['type']).toLowerCase() == 'zonk' ? 'zonk' : '',
        'color': '#334155',
        'is_hidden': false,
      };

      /*
       * SERVER-AUTHORITATIVE WHEEL POSITION
       *
       * secure_spin_with_auth sekarang menentukan wheel_index di Supabase.
       * Flutter TIDAK lagi mengira index berdasarkan reward_id.
       *
       * wheel_index = slot visible 0-based
       * wheel_total = jumlah slot visible ketika spin diproses
       */
      final serverWheelIndex = int.tryParse(
            _string(result['wheel_index']),
          );
      final serverWheelTotal = int.tryParse(
            _string(result['wheel_total']),
          );

      if (serverWheelIndex == null || serverWheelIndex < 0) {
        throw Exception('Server tidak memulangkan wheel_index yang sah.');
      }

      if (serverWheelTotal == null || serverWheelTotal <= 0) {
        throw Exception('Server tidak memulangkan wheel_total yang sah.');
      }

      /*
       * Pastikan data visual Flutter masih sepadan dengan snapshot server.
       * Jika admin baru sahaja ubah/hidden reward selepas wheel dimuatkan,
       * muat semula sekali supaya susunan visual menggunakan susunan terkini.
       */
      var visiblePool = prizes.where((p) => p['is_hidden'] != true).toList();

      if (visiblePool.length != serverWheelTotal) {
        await _loadPrizes();
        visiblePool = prizes.where((p) => p['is_hidden'] != true).toList();
      }

      /*
       * Selepas server menentukan slot, index itu tidak boleh digantikan
       * dengan index berdasarkan reward_id. Kalau snapshot masih berbeza,
       * kita hentikan animasi daripada menunjuk hadiah yang salah.
       */
      if (visiblePool.length != serverWheelTotal ||
          serverWheelIndex >= visiblePool.length) {
        throw Exception(
          'Susunan roda berubah. Sila tekan putar semula.',
        );
      }

      final prizeIndex = serverWheelIndex;
      final totalVisibleItems = serverWheelTotal;
      final frontendPrizeAtServerIndex = visiblePool[serverWheelIndex];
      final indexRewardIdMatches =
          _string(frontendPrizeAtServerIndex['id']) ==
          _string(result['reward_id']);


      if (!indexRewardIdMatches) {
        throw Exception(
          'Server index tidak sepadan dengan hadiah pada slot Flutter.',
        );
      }
      final sliceAngle = 360.0 / totalVisibleItems;

      /*
       * Titik berhenti masih boleh sedikit rawak DALAM slot yang
       * telah ditentukan server. Random ini hanya mengubah titik visual,
       * bukan hadiah yang dimenangi.
       */
      final random = math.Random();
      final randomOffset =
          (random.nextDouble() * 2.0 - 1.0) * (sliceAngle * 0.42);

      final stopAngleDeg =
          360.0 -
          (prizeIndex * sliceAngle) -
          (sliceAngle / 2.0) +
          randomOffset;

      final fullTurn = 2 * math.pi;
      final stopAngleRad = stopAngleDeg * math.pi / 180.0;

      /*
       * SAMA DENGAN:
       *
       * currentRotation +
       * (8 * 360) +
       * stopAngle -
       * (currentRotation % 360)
       */
      final finalRotation =
          currentRotation +
          (8 * fullTurn) +
          stopAngleRad -
          (currentRotation % fullTurn);

      final expectedVisualSlot =
          _visualSlotFromRotation(
            finalRotation,
            totalVisibleItems,
          );

      final visualSlotMatchesServer =
          expectedVisualSlot == serverWheelIndex;


      if (!visualSlotMatchesServer) {
        throw Exception(
          'Kiraan visual Flutter tidak sepadan dengan wheel_index server.',
        );
      }

      _animationStartRotation = currentRotation;
      _animationTargetRotation = finalRotation;
      selectedPrize = winner;
      trackingNumber = _string(result['tracking_number']);

      setState(() {});

      _lastSoundSlice = -1;
      _lastSoundAt = DateTime.fromMillisecondsSinceEpoch(0);

      await _animationController.forward(from: 0);

      if (!mounted) return;

      setState(() {
        currentRotation = finalRotation;
        spinning = false;
      });


      rewardCodeController.clear();

      await Future<void>.delayed(
        const Duration(milliseconds: 100),
      );

      if (!mounted) return;

      final prize = winner;

      if (_isZonk(prize, result)) {
        await _showZonkDialog();
        return;
      }
      /*
       * SAMA SEPERTI index.html:
       * ICE CASH dikreditkan oleh database trigger.
       * Flutter cuma baca baki.
       */
      if (_isIceCash(prize)) {
        try {
          final walletData =
              await client.rpc('ice_cash_my_account');

          final creditedAmount =
              double.tryParse(
                    _string(
                      prize['ice_cash_amount'] ??
                          result['ice_cash_amount'] ??
                          0,
                    ),
                  ) ??
                  0;

          final currentBalance =
              double.tryParse(
                    _string(
                      walletData is Map ? walletData['balance'] : 0,
                    ),
                  ) ??
                  0;

          prize['_iceCashCredited'] = true;
          prize['_iceCashCreditAmount'] = creditedAmount;
          prize['_iceCashBalance'] = currentBalance;

          _toast(
            '+$creditedAmount ICE CASH telah dimasukkan ke akaun anda.',
          );
        } catch (e) {
          prize['_iceCashCredited'] = false;
          prize['_iceCashCreditError'] =
              _cleanError(e).isEmpty
                  ? 'Gagal membaca baki ICE CASH.'
                  : _cleanError(e);

          _toast(
            'Hadiah ICE CASH telah diproses oleh server. '
            'Sila segarkan sejarah/baki.',
          );
        }
      }

      await _showWinnerDialog(prize);
    } catch (e) {
      if (!mounted) return;

      setState(() {
        spinning = false;
      });

      _toast(_cleanError(e), error: true);
    }
  }

  Future<void> _showZonkDialog() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF11182B),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: const Text(
            'KURANG BERUNTUNG!',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: 22,
            ),
          ),
          content: const Text(
            'Jangan risau, cuba kod reward lain untuk peluang memenangi hadiah seterusnya.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white60,
              height: 1.5,
            ),
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFB000),
                foregroundColor: Colors.black,
              ),
              child: const Text(
                'CUBA LAGI',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
          ],
        );
      },
    );
  }

Future<void> _showWinnerDialog(
  Map<String, dynamic> prize,
) async {
  gameIdController.clear();
  zoneIdController.clear();
  _winnerTrackingVisible = false;

  // Setiap hadiah baharu mesti bermula dengan borang yang bersih.
  // Elak spinner lama kekal selepas tuntutan terdahulu ditutup.
  submittingClaim = false;

  final isIceCash = _isIceCash(prize);
  final isWhatsappOrTng = _isWhatsappOrTng(prize);
  final needsGame = _needsGameId(prize);
  final needsZone = _needsZoneId(prize);

  final amount =
        double.tryParse(
              _string(
                prize['_iceCashCreditAmount'] ??
                    prize['ice_cash_amount'] ??
                    0,
              ),
            ) ??
            0;

    final credited = prize['_iceCashCredited'] == true;

    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF11182B),
              insetPadding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 20,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              title: const Column(
                children: [
                  Icon(
                    Icons.emoji_events_rounded,
                    color: Color(0xFFFFD166),
                    size: 48,
                  ),
                  SizedBox(height: 5),
                  Text(
                    'TAHNIAH!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 22,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Anda telah berjaya memenangi:',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: [
                    _winnerCard(prize, onToggleTracking: () => setDialogState(() => _winnerTrackingVisible = !_winnerTrackingVisible)),
                    const SizedBox(height: 12),

                    if (isIceCash)
                      _iceCashSection(
                        amount: amount,
                        credited: credited,
                        balance: double.tryParse(
                              _string(prize['_iceCashBalance']),
                            ) ??
                            0,
                        error: _string(
                          prize['_iceCashCreditError'],
                        ),
                      ),

                    if (!isIceCash && isWhatsappOrTng)
                      _whatsappSection(prize),

                    if (!isIceCash && !isWhatsappOrTng)
                      _claimForm(
                        prize: prize,
                        needsGame: needsGame,
                        needsZone: needsZone,
                        setDialogState: setDialogState,
                        dialogContext: dialogContext,
                      ),
                  ],
                ),
              ),
              actionsAlignment: MainAxisAlignment.center,
              actions: [
                TextButton(
                  // Pengguna sentiasa boleh menutup dialog walaupun permintaan
                  // rangkaian sedang menunggu.
                  onPressed: () {
                    if (dialogContext.mounted) {
                      Navigator.pop(dialogContext);
                    }
                    submittingClaim = false;
                  },
                  child: const Text(
                    'TUTUP',
                    style: TextStyle(
                      color: Colors.white54,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _winnerCard(Map<String, dynamic> prize, {VoidCallback? onToggleTracking}) {
    final url = _prizeImage(prize);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF052E1B),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.greenAccent.withValues(alpha: .22),
        ),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: url.isEmpty
                ? Container(
                    width: 58,
                    height: 58,
                    color: const Color(0xFF0F172A),
                    child: const Icon(
                      Icons.card_giftcard_rounded,
                      color: Color(0xFFFFD166),
                      size: 30,
                    ),
                  )
                : Image.network(
                    url,
                    width: 58,
                    height: 58,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 58,
                        height: 58,
                        color: const Color(0xFF0F172A),
                        child: const Icon(
                          Icons.card_giftcard_rounded,
                          color: Color(0xFFFFD166),                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _prizeName(prize),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF34D399),
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 7),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F172A),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Tracking: ${trackingNumber.isEmpty ? '-' : (_winnerTrackingVisible ? trackingNumber : '••••••••••••')}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontFamily: 'monospace',
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      IconButton(
                        tooltip: _winnerTrackingVisible ? 'Sembunyikan tracking' : 'Lihat tracking',
                        visualDensity: VisualDensity.compact,
                        constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                        padding: EdgeInsets.zero,
                        onPressed: onToggleTracking,
                        icon: Icon(
                          _winnerTrackingVisible ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                          color: Colors.white70,
                          size: 17,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Salin tracking',
                        visualDensity: VisualDensity.compact,
                        constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                        padding: EdgeInsets.zero,
                        onPressed: trackingNumber.isEmpty ? null : () async {
                          await Clipboard.setData(ClipboardData(text: trackingNumber));
                          if (mounted) {
                            ScaffoldMessenger.of(this.context).showSnackBar(
                              const SnackBar(content: Text('Tracking berjaya disalin')),
                            );
                          }
                        },
                        icon: const Icon(Icons.copy_rounded, color: Color(0xFF93C5FD), size: 17),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _iceCashSection({
    required double amount,
    required bool credited,
    required double balance,
    required String error,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0x33F59E0B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0x66F59E0B),
        ),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.monetization_on_rounded,
            color: Color(0xFFFFD166),
            size: 48,
          ),
          const SizedBox(height: 6),
          const Text(
            'ICE CASH TELAH DIKREDITKAN',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFFFFE7A3),
              fontSize: 10,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            '+${amount.toStringAsFixed(2)} ICE CASH',
            style: const TextStyle(
              color: Color(0xFFFFD166),
              fontSize: 23,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            credited
                ? 'Baki ICE CASH anda sekarang: ${balance.toStringAsFixed(2)}'
                : (error.isEmpty
                    ? 'Kredit belum disahkan. Sila semak sejarah.'
                    : error),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: credited
                  ? const Color(0xFFA7F3D0)
                  : const Color(0xFFFDE68A),
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(Icons.storefront_rounded),
              label: const Text('BUKA ICE CASH SHOP'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFB000),
                foregroundColor: Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _whatsappSection(Map<String, dynamic> prize) {
    final username =
        _string(currentUser?['username']).isEmpty
            ? _string(currentUser?['email'])
            : _string(currentUser?['username']);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0x2210B981),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0x4434D399),
        ),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.chat_rounded,
            color: Color(0xFF34D399),
            size: 35,
          ),
          const SizedBox(height: 8),
          const Text(
            'TEBUS MELALUI WHATSAPP',
            style: TextStyle(
              color: Color(0xFF86EFAC),
              fontWeight: FontWeight.w900,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0x221F2937),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              'Ganjaran ini hanya boleh ditebus melalui WhatsApp rasmi Admin.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFFFECACA),
                fontSize: 10,
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tracking ID: $trackingNumber',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () async {
                final message = Uri.encodeComponent(
                  'Hai Admin ICEDRAGONSTORE,\n\n'
                  'Saya ingin menebus ganjaran berikut:\n'
                  'Hadiah: ${_prizeName(prize)}\n'
                  'Username: $username\n'
                  'Tracking ID: $trackingNumber\n\n'
                  'Sila bantu proses tuntutan saya. Terima kasih!',
                );

                final uri = Uri.parse(
                  'https://wa.me/601135268529?text=$message',
                );

                try {
                  await launchUrl(uri);
                } catch (_) {
                  _toast(
                    'Tidak dapat membuka WhatsApp.',
                    error: true,
                  );
                }
              },
              icon: const Icon(Icons.chat_rounded),
              label: const Text('TEBUS MELALUI WHATSAPP NOW'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF059669),
                foregroundColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _claimForm({
    required Map<String, dynamic> prize,
    required bool needsGame,
    required bool needsZone,
    required StateSetter setDialogState,
    required BuildContext dialogContext,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0x990F172A),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.edit_note_rounded,
                color: Color(0xFF34D399),
              ),
              const SizedBox(width: 7),
              const Expanded(
                child: Text(
                  'BORANG MAKLUMAT TUNTUTAN',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
          if (needsGame) ...[
            const SizedBox(height: 12),
            _input(
              controller: gameIdController,
              label: 'GAME ID / ID PEMAIN *',
              hint: 'Contoh: 12345678',
              icon: Icons.sports_esports_rounded,
            ),
          ],
          if (needsZone) ...[
            const SizedBox(height: 12),
            _input(
              controller: zoneIdController,
              label: 'ZONE / SERVER ID *',
              hint: 'Contoh: 2124',
              icon: Icons.public_rounded,
            ),
          ],
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0x221F2937),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0x5534D399),
              ),
            ),
            child: const Text(
              'Penting: Sila pastikan maklumat diisi dengan tepat. '
              'ICEDRAGONSTORE tidak bertanggungjawab atas kesalahan '
              'maklumat yang diberikan pengguna.',
              style: TextStyle(
                color: Color(0xFFFECACA),
                fontSize: 9,
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: submittingClaim
                  ? null
                  : () async {
                      setDialogState(() {
                        submittingClaim = true;
                      });

                      var ok = false;
                      try {
                        // Hadkan masa menunggu supaya borang tidak tersangkut
                        // selama-lamanya jika rangkaian/API tidak memberi respons.
                        ok = await _submitClaim().timeout(
                          const Duration(seconds: 20),
                          onTimeout: () {
                            _toast(
                              'Sambungan mengambil masa terlalu lama. '
                              'Semak internet dan cuba lagi.',
                              error: true,
                            );
                            return false;
                          },
                        );
                      } catch (e) {
                        _toast(_cleanError(e), error: true);
                        ok = false;
                      } finally {
                        // Reset walaupun dialog sudah ditutup oleh pengguna.
                        submittingClaim = false;
                        if (mounted && dialogContext.mounted) {
                          setDialogState(() {});
                        }
                      }

                      if (!mounted || !dialogContext.mounted) return;

                      if (ok) {
                        Navigator.pop(dialogContext);
                        await _showSubmittedDialog();
                      }
                    },
              icon: submittingClaim
                  ? const SizedBox(
                      width: 17,
                      height: 17,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.black,
                      ),
                    )
                  : const Icon(Icons.send_rounded),
              label: Text(
                submittingClaim
                    ? 'MENGHANTAR...'
                    : 'HANTAR MAKLUMAT TUNTUTAN',
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF34D399),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 13),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _input({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 9,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 5),
        TextField(
          controller: controller,
          enabled: !submittingClaim,
          textInputAction: TextInputAction.next,
          keyboardType: TextInputType.text,
          autocorrect: false,
          enableSuggestions: false,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(
              color: Colors.white30,
              fontSize: 11,
            ),
            prefixIcon: Icon(
              icon,
              color: const Color(0xFFFFB000),
              size: 20,
            ),
            filled: true,
            fillColor: const Color(0x99080D1C),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.white12),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.white12),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFFFFB000),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<bool> _submitClaim() async {
    // Halang permintaan berganda dalam instance halaman yang sama.
    if (_claimRequestInFlight) {
      _toast(
        'Permintaan tuntutan sedang diproses. Sila tunggu sebentar.',
        error: true,
      );
      return false;
    }

    final gameId = gameIdController.text.trim();
    final zoneId = zoneIdController.text.trim();
    final prize = selectedPrize;

    if (prize == null) {
      _toast('Hadiah tidak dijumpai.', error: true);
      return false;
    }

    final req = _requirement(prize);

    if ((req == 'game' || req == 'game_zone') && gameId.isEmpty) {
      _toast('Sila masukkan Game ID / ID Pemain terlebih dahulu!', error: true);
      return false;
    }

    if (req == 'game_zone' && zoneId.isEmpty) {
      _toast('Sila masukkan Zone / Server ID terlebih dahulu!', error: true);
      return false;
    }

    if (trackingNumber.isEmpty) {
      _toast('Tracking number tidak tersedia.', error: true);
      return false;
    }

    _claimRequestInFlight = true;

    try {
      /*
       * Gunakan RPC yang sama seperti halaman History.
       * UPDATE terus melalui PostgREST boleh nampak berjaya walaupun RLS
       * menyebabkan 0 baris dikemas kini. RPC mengesahkan pemilikan tuntutan
       * dan menyimpan Game ID/Zone ID di sebelah server.
       */
      final result = await client.rpc(
        'update_my_claim_details',
        params: {
          'p_tracking_number': trackingNumber,
          'p_game_id': gameId.isEmpty ? null : gameId,
          'p_zone_id': zoneId.isEmpty ? null : zoneId,
        },
      ).timeout(const Duration(seconds: 20));

      if (result is Map && result['success'] == false) {
        throw Exception(
          result['message']?.toString() ??
              'Maklumat tuntutan gagal dikemaskini.',
        );
      }

      // Jika RPC memulangkan boolean false atau bentuk respons gagal,
      // jangan tunjuk kejayaan palsu.
      if (result == false) {
        throw Exception('Maklumat tuntutan gagal dikemaskini.');
      }

      _toast('Maklumat tuntutan berjaya disimpan.');
      return true;
    } catch (e) {
      _toast(_cleanError(e), error: true);
      return false;
    } finally {
      _claimRequestInFlight = false;
    }
  }

  Future<void> _showSubmittedDialog() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF11182B),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.check_circle_rounded,
                color: Color(0xFF34D399),
                size: 65,
              ),
              const SizedBox(height: 10),
              const Text(
                'Maklumat Berjaya Dihantar!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                ),
              ),
              const SizedBox(height: 7),
              const Text(
                'Admin akan memproses tuntutan anda dalam masa terdekat.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 11,
                  height: 1.4,
                ),
              ),
            ],
          ),
          actionsAlignment: MainAxisAlignment.center,
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pop(dialogContext),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF34D399),
                foregroundColor: Colors.black,
              ),
              child: const Text(
                'TUTUP',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _wheel() {
    if (prizes.isEmpty) {
      return Container(
        width: 330,
        height: 330,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF11182B),
          border: Border.all(
            color: const Color(0xFFFFB000),
            width: 4,
          ),
        ),
        child: const Center(
          child: Text(
            'TIADA HADIAH',
            style: TextStyle(
              color: Colors.white54,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      );
    }

    // Roda berada di dalam padding halaman dan kad. Tolak kedua-dua
    // lapisan padding supaya roda tidak melimpah pada skrin telefon kecil.
    final available = MediaQuery.of(context).size.width - 72;
    final wheelSize = math.max(220.0, math.min(available, 370.0));

return SizedBox(
  width: wheelSize,
  height: wheelSize,
  child: AnimatedBuilder(
    animation: _animationController,
    builder: (context, child) {
      final t = _animationController.value;
      final progress = Curves.easeOutQuart.transform(t);
      final rotation = _animationStartRotation +
          (_animationTargetRotation - _animationStartRotation) * progress;

      return Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          // Lapisan roda sahaja yang berpusing.
          Transform.rotate(
            angle: rotation,
            // Roda ialah imej komposit yang berpusing; kualiti rendah
            // mengurangkan kos sampling tanpa menjejaskan teks/imej asal.
            filterQuality: FilterQuality.low,
            child: child,
          ),

          // Jarum merah klasik: hujungnya menunjuk tepat ke bahagian hadiah.
          // Ia kekal statik dan tidak berpusing bersama roda.
          Positioned(
            top: -9,
            left: 0,
            right: 0,
            child: IgnorePointer(
              child: Center(
                child: SizedBox(
                  width: 34,
                  height: 31,
                  child: CustomPaint(
                    painter: _WheelPointerPainter(),
                  ),
                ),
              ),
            ),
          ),

          // Hub tengah statik dengan bingkai emas, tanpa lampu berkelip.
          SizedBox(
            width: wheelSize * .205,
            height: wheelSize * .205,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF0F172A),
                border: Border.all(
                  color: const Color(0xFFFFC857),
                  width: 4,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x55FFB52E),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                  BoxShadow(
                    color: Colors.black54,
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Center(
                child: Text(
                  'ICE\nWHELL',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFFFB000),
                    fontSize: 12,
                    height: 1.05,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .5,
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    },
    child: RepaintBoundary(
      child: SizedBox(
        width: wheelSize,
        height: wheelSize,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              size: Size(wheelSize, wheelSize),
              painter: _WheelPainter(
                prizes: prizes,
                colors: prizes.map(_prizeColor).toList(),
              ),
            ),
            ...List.generate(prizes.length, (index) {
              final slice = 2 * math.pi / prizes.length;
              final angle = -math.pi / 2 + (index + 0.5) * slice;
              final radius = wheelSize * .34;
              final x = math.cos(angle) * radius;
              final y = math.sin(angle) * radius;
              final prize = prizes[index];

              return Transform.translate(
                offset: Offset(x, y),
                child: Transform.rotate(
                  angle: angle + math.pi / 2,
                  child: SizedBox(
                    width: wheelSize * .25,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _smallPrizeImage(prize, wheelSize * .12),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 5,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFF0F172A),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.white, width: 1),
                          ),
                          child: Text(
                            _prizeName(prize),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 8,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    ),
  ),
);
  }

  Widget _smallPrizeImage(
    Map<String, dynamic> prize,
    double size,
  ) {
    final url = _prizeImage(prize);

    if (url.isEmpty) {
      return Icon(
        Icons.card_giftcard_rounded,
        color: Colors.white70,
        size: size * .65,
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Image.network(
        url,
        width: size,
        height: size,
        // Decode terus pada saiz paparan untuk elak imej hadiah besar
        // menggunakan RAM berlebihan ketika animasi roda berjalan.
        cacheWidth: math.max(
          1,
          (size * MediaQuery.devicePixelRatioOf(context)).round(),
        ),
        cacheHeight: math.max(
          1,
          (size * MediaQuery.devicePixelRatioOf(context)).round(),
        ),
        fit: BoxFit.contain,
        filterQuality: FilterQuality.low,
        errorBuilder: (context, error, stackTrace) {
          return Icon(
            Icons.card_giftcard_rounded,
            color: Colors.white70,
            size: size * .65,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: const AppBottomNav(currentIndex: 1),
      backgroundColor: const Color(0xFF070B19),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: const Color(0xFF070B19),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ICEDRAGONSTORE',
              style: TextStyle(
                color: Color(0xFFFFD166),
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            Text(
              'RODA BERTUAH',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: _soundEnabled ? 'Mute suara roda' : 'Hidupkan suara roda',
            onPressed: () => _setSoundEnabled(!_soundEnabled),
            icon: Icon(
              _soundEnabled
                  ? Icons.volume_up_rounded
                  : Icons.volume_off_rounded,
            ),
          ),
          IconButton(
            tooltip: 'Sejarah spin',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const HistorySpinPage(),
                ),
              );
            },
            icon: const Icon(Icons.history_rounded),
          ),
          IconButton(
            tooltip: 'Segarkan hadiah',
            onPressed: loading ? null : _loadPrizes,
            icon: const Icon(Icons.refresh_rounded),
          ),
        
          notificationAction(context),],
      ),
      body: RefreshIndicator(
        color: const Color(0xFFFFB000),
        backgroundColor: const Color(0xFF11182B),
        onRefresh: _loadPrizes,
        child: loading
            ? const SkeletonLoading(type: SkeletonType.wheel)
            : ListView(
                physics:
                    const AlwaysScrollableScrollPhysics(),
                padding:
                    const EdgeInsets.fromLTRB(
                  14,
                  12,
                  14,
                  30,
                ),
                children: [
                  Container(
                    padding:
                        const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xEE151D32),
                          Color(0xEE0B1020),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: const Color(0x44FFB000),
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x33000000),
                          blurRadius: 22,
                          offset: Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Text(
                          'RODA BERTUAH',
                          style: TextStyle(
                            color: Color(0xFFFFD166),
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 5),
                        const Text(
                          'Masukkan kod reward yang sah untuk mencuba nasib anda.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white60,
                            fontSize: 11,
                            height: 1.45,
                          ),
                        ),
                        // Label bilangan hadiah tersedia dibuang seperti diminta.
                        const SizedBox(height: 16),
                        _wheel(),
                        const SizedBox(height: 18),
                        TextField(
                          controller: rewardCodeController,
                          enabled: !spinning,
                          textInputAction: TextInputAction.done,
                          onSubmitted: (_) {
                            if (!spinning) _spin();
                          },
                          textCapitalization:
                              TextCapitalization
                                  .characters,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight:
                                FontWeight.w800,
                            letterSpacing: 1,
                          ),
                          decoration:
                              InputDecoration(
                            hintText:
                                'MASUKKAN KOD REWARD',
                            hintStyle:
                                const TextStyle(
                              color: Colors.white30,
                              fontSize: 12,
                            ),
                            prefixIcon:
                                const Icon(
                              Icons
                                  .confirmation_number_rounded,
                              color:
                                  Color(0xFFFFB000),
                            ),
                            filled: true,
                            fillColor:
                                const Color(0x99080D1C),
                            border:
                                OutlineInputBorder(
                              borderRadius:
                                  BorderRadius
                                      .circular(15),
                              borderSide:
                                  const BorderSide(
                                color:
                                    Colors.white12,
                              ),
                            ),
                            enabledBorder:
                                OutlineInputBorder(
                              borderRadius:
                                  BorderRadius
                                      .circular(15),
                              borderSide:
                                  const BorderSide(
                                color:
                                    Colors.white12,
                              ),
                            ),
                            focusedBorder:
                                OutlineInputBorder(
                              borderRadius:
                                  BorderRadius
                                      .circular(15),
                              borderSide:
                                  const BorderSide(
                                color:
                                    Color(0xFFFFB000),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child:
                              ElevatedButton.icon(
                            onPressed: spinning ? null : _spin,
                            icon: spinning
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2.2,
                                      color: Colors.black,
                                    ),
                                  )
                                : const Icon(Icons.play_circle_fill_rounded),
                            label: Text(
                              spinning
                                  ? 'SEDANG MEMUTAR...'
                                  : 'PUTAR SEKARANG',
                            ),
                            style:
                                ElevatedButton
                                    .styleFrom(
                              backgroundColor:
                                  const Color(
                                      0xFFFFB000),
                              foregroundColor:
                                  Colors.black,
                              disabledBackgroundColor:
                                  Colors.white12,
                              padding:
                                  const EdgeInsets
                                      .symmetric(
                                vertical: 15,
                              ),
                              shape:
                                  RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius
                                        .circular(15),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _WheelPointerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(size.width * .08, size.height * .08)
      ..quadraticBezierTo(
        size.width * .5,
        size.height * -.02,
        size.width * .92,
        size.height * .08,
      )
      ..lineTo(size.width * .57, size.height * .77)
      ..quadraticBezierTo(
        size.width * .5,
        size.height * .98,
        size.width * .43,
        size.height * .77,
      )
      ..close();

    canvas.drawShadow(path, Colors.black.withValues(alpha: .65), 4, true);
    canvas.drawPath(
      path,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFFFF4C2),
            Color(0xFFFFB52E),
            Color(0xFFFFD978),
          ],
        ).createShader(Offset.zero & size)
        ..style = PaintingStyle.fill,
    );

    final inner = Path()
      ..moveTo(size.width * .19, size.height * .16)
      ..lineTo(size.width * .81, size.height * .16)
      ..lineTo(size.width * .56, size.height * .72)
      ..quadraticBezierTo(
        size.width * .5,
        size.height * .84,
        size.width * .44,
        size.height * .72,
      )
      ..close();

    canvas.drawPath(
      inner,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFFF6B6B),
            Color(0xFFDC2626),
            Color(0xFF991B1B),
          ],
        ).createShader(Offset.zero & size),
    );

    final jewelCenter = Offset(size.width * .5, size.height * .43);
    canvas.drawCircle(
      jewelCenter,
      size.width * .105,
      Paint()..color = const Color(0xFFFFF0B5),
    );
    canvas.drawCircle(
      jewelCenter,
      size.width * .065,
      Paint()..color = const Color(0xFFFFD166),
    );
  }

  @override
  bool shouldRepaint(covariant _WheelPointerPainter oldDelegate) => false;
}

class _WheelPainter extends CustomPainter {
  final List<Map<String, dynamic>> prizes;
  final List<Color> colors;

  const _WheelPainter({
    required this.prizes,
    required this.colors,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2;
    final count = math.max(prizes.length, 1);
    final sweep = 2 * math.pi / count;
    final wheelRect = Rect.fromCircle(center: center, radius: radius - 4);

    // Soft gold glow behind the outer rim.
    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12
      ..color = const Color(0xFFFFB000).withValues(alpha: .18)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7);
    canvas.drawCircle(center, radius - 5, glowPaint);

    // Fill each prize slice.
    final fillPaint = Paint()..style = PaintingStyle.fill;
    for (int i = 0; i < count; i++) {
      fillPaint.color = i < colors.length
          ? colors[i]
          : const Color(0xFF334155);

      final startAngle = -math.pi / 2 + i * sweep;
      canvas.drawArc(wheelRect, startAngle, sweep, true, fillPaint);
    }

    // Gold dividers from the centre to the outside edge, like the reference.
    final dividerPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.2, size.width * .004)
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFFFFD166);

    for (int i = 0; i < count; i++) {
      final angle = -math.pi / 2 + i * sweep;
      final start = Offset(
        center.dx + math.cos(angle) * (radius * .12),
        center.dy + math.sin(angle) * (radius * .12),
      );
      final end = Offset(
        center.dx + math.cos(angle) * (radius - 5),
        center.dy + math.sin(angle) * (radius - 5),
      );
      canvas.drawLine(start, end, dividerPaint);
    }

    // Gold outer frame with a brighter inner highlight.
    final outerShadowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..color = const Color(0xFFFF9F1C).withValues(alpha: .72);
    canvas.drawCircle(center, radius - 4.5, outerShadowPaint);

    final outerRimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5
      ..shader = const SweepGradient(
        colors: [
          Color(0xFFFFF1B8),
          Color(0xFFFFB52E),
          Color(0xFFFFE8A3),
          Color(0xFFFF9F1C),
          Color(0xFFFFF1B8),
        ],
      ).createShader(wheelRect);
    canvas.drawCircle(center, radius - 5, outerRimPaint);

    final innerRimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = const Color(0xFFFFF0B5).withValues(alpha: .9);
    canvas.drawCircle(center, radius - 9, innerRimPaint);

    // Deliberately no inner white circle: it used to cross over prize artwork
    // and labels, making the wheel look cluttered.
  }

  @override
  bool shouldRepaint(covariant _WheelPainter oldDelegate) {
    return oldDelegate.prizes != prizes ||
        oldDelegate.colors != colors;
  }
}
