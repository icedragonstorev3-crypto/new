import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../widgets/top_toast.dart';
import '../widgets/skeleton_loading.dart';

class WalletPage extends StatefulWidget {
  const WalletPage({super.key});

  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  final SupabaseClient _client = Supabase.instance.client;
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _receiptController = TextEditingController();

  bool _loading = true;
  bool _submitting = false;
  double _balance = 0;
  List<Map<String, dynamic>> _requests = [];

  @override
  void initState() {
    super.initState();
    _loadWallet();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _receiptController.dispose();
    super.dispose();
  }

  double _asDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '') ?? 0;
  }

  String _cleanError(Object error) {
    final text = error.toString();
    return text.startsWith('Exception: ') ? text.substring(11) : text;
  }

  void _message(String message, {bool error = false}) {
    if (!mounted) return;
    TopToast.show(context, message, error: error);
  }

  Future<void> _loadWallet() async {
    setState(() => _loading = true);
    try {
      if (_client.auth.currentSession == null) {
        throw Exception('Sila log masuk terlebih dahulu.');
      }
      final results = await Future.wait<dynamic>([
        _client.rpc('rm_wallet_my_balance'),
        _client.rpc('rm_wallet_my_topups'),
      ]);
      final balanceResult = results[0];
      dynamic rawBalance;
      if (balanceResult is Map) {
        rawBalance = balanceResult['balance'] ?? balanceResult['rm_balance'];
      } else {
        rawBalance = balanceResult;
      }

      final requestResult = results[1];
      final requests = requestResult is List
          ? requestResult
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .toList()
          : <Map<String, dynamic>>[];

      if (!mounted) return;
      setState(() {
        _balance = _asDouble(rawBalance);
        _requests = requests;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      _message(_cleanError(e), error: true);
    }
  }

  Future<void> _requestTopup() async {
    final amount = double.tryParse(_amountController.text.trim());
    final receiptUrl = _receiptController.text.trim();

    if (amount == null || amount <= 0 || amount > 5000) {
      _message('Masukkan jumlah antara RM0.01 hingga RM5,000.', error: true);
      return;
    }
    final uri = Uri.tryParse(receiptUrl);
    if (uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http') ||
        uri.host.isEmpty) {
      _message('Masukkan pautan resit pembayaran yang sah.', error: true);
      return;
    }

    setState(() => _submitting = true);
    try {
      final result = await _client.rpc(
        'rm_wallet_request_topup',
        params: {
          'p_amount': amount,
          'p_receipt_url': receiptUrl,
        },
      );
      if (result is Map && result['success'] == false) {
        throw Exception(result['message']?.toString() ?? 'Permintaan gagal.');
      }
      _amountController.clear();
      _receiptController.clear();
      _message('Permintaan tambah nilai dihantar. Tunggu pengesahan admin.');
      await _loadWallet();
    } catch (e) {
      _message(_cleanError(e), error: true);
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Color _statusColor(String status) {
    switch (status.toUpperCase()) {
      case 'APPROVED':
        return const Color(0xFF35C98A);
      case 'REJECTED':
        return const Color(0xFFFF6262);
      default:
        return const Color(0xFFFFB000);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF070A18),
      appBar: AppBar(
        title: const Text('Dompet RM'),
        backgroundColor: const Color(0xFF070A18),
        actions: [
          IconButton(
            onPressed: _loadWallet,
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Muat semula',
          ),
        ],
      ),
      body: _loading
          ? const SkeletonLoading(type: SkeletonType.wallet)
          : RefreshIndicator(
              onRefresh: _loadWallet,
              child: ListView(
                padding: const EdgeInsets.all(18),
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: const Color(0xFF151D32),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0x33FFB000)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(
                          Icons.account_balance_wallet_rounded,
                          color: Color(0xFFFFB000),
                          size: 32,
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Baki tersedia',
                          style: TextStyle(color: Colors.white60),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'RM ${_balance.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  const Text(
                    'Tambah nilai manual',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Buat pembayaran terlebih dahulu, kemudian masukkan jumlah dan pautan resit. Admin akan menyemak sebelum baki dikreditkan.',
                    style: TextStyle(color: Colors.white60, height: 1.4),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _amountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: 'Jumlah (RM)',
                      prefixText: 'RM ',
                      filled: true,
                      fillColor: const Color(0xFF151D32),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _receiptController,
                    keyboardType: TextInputType.url,
                    decoration: InputDecoration(
                      labelText: 'Pautan resit pembayaran',
                      hintText: 'https://...',
                      filled: true,
                      fillColor: const Color(0xFF151D32),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 50,
                    child: FilledButton(
                      onPressed: _submitting ? null : _requestTopup,
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFFFB000),
                        foregroundColor: Colors.black,
                      ),
                      child: _submitting
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.black,
                              ),
                            )
                          : const Text(
                              'Hantar Permintaan',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                    ),
                  ),
                  const SizedBox(height: 26),
                  const Text(
                    'Sejarah tambah nilai',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 10),
                  if (_requests.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: Text(
                        'Belum ada permintaan tambah nilai.',
                        style: TextStyle(color: Colors.white54),
                      ),
                    )
                  else
                    ..._requests.map((request) {
                      final status = request['status']?.toString() ?? 'PENDING';
                      final amount = _asDouble(request['amount']);
                      final tracking = request['tracking_number']?.toString() ?? '-';
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: const Color(0xFF151D32),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white10),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    'RM ${amount.toStringAsFixed(2)}',
                                    style: const TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                                Text(
                                  status,
                                  style: TextStyle(
                                    color: _statusColor(status),
                                    fontWeight: FontWeight.w800,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 5),
                            Text(
                              'Rujukan: $tracking',
                              style: const TextStyle(color: Colors.white60, fontSize: 12),
                            ),
                            if ((request['admin_note']?.toString() ?? '').isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: Text(
                                  'Nota admin: ${request['admin_note']}',
                                  style: const TextStyle(color: Colors.white60, fontSize: 12),
                                ),
                              ),
                          ],
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }
}
