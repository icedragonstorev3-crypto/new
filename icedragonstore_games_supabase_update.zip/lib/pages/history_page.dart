import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../widgets/skeleton_loading.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final SupabaseClient client = Supabase.instance.client;
  List<Map<String, dynamic>> orders = [];
  bool loading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    setState(() { loading = true; errorMessage = null; });
    try {
      if (client.auth.currentSession == null) {
        throw Exception('Sila log masuk untuk melihat sejarah pembelian.');
      }
      final result = await client.rpc('rm_shop_my_orders').timeout(const Duration(seconds: 25));
      final loaded = result is List
          ? result.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
          : <Map<String, dynamic>>[];
      if (!mounted) return;
      setState(() { orders = loaded; });
    } catch (e) {
      if (!mounted) return;
      setState(() { errorMessage = e.toString().replaceFirst('Exception: ', ''); });
    } finally {
      if (mounted) setState(() { loading = false; });
    }
  }

  String _text(dynamic value) {
    final s = value?.toString().trim() ?? '';
    return s.isEmpty || s == 'null' ? '-' : s;
  }

  String _money(dynamic value) {
    final n = double.tryParse(value?.toString() ?? '') ?? 0;
    return 'RM ${n.toStringAsFixed(2)}';
  }

  Color _statusColor(String status) {
    final s = status.toLowerCase();
    if (s.contains('success') || s.contains('complete') || s.contains('berjaya')) return const Color(0xFF57D69A);
    if (s.contains('cancel') || s.contains('fail') || s.contains('reject')) return const Color(0xFFFF7373);
    return const Color(0xFFFFC857);
  }

  String _formatDate(dynamic value) {
    final raw = value?.toString().trim() ?? '';
    if (raw.isEmpty || raw == 'null') return '-';
    final parsed = DateTime.tryParse(raw);
    if (parsed == null) return raw;
    final local = parsed.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    const months = ['Jan', 'Feb', 'Mac', 'Apr', 'Mei', 'Jun', 'Jul', 'Ogo', 'Sep', 'Okt', 'Nov', 'Dis'];
    return '${two(local.day)} ${months[local.month - 1]} ${local.year}, ${two(local.hour)}:${two(local.minute)}:${two(local.second)}';
  }

  Future<void> _copyTracking(String tracking) async {
    if (tracking.trim().isEmpty || tracking == '-') return;
    await Clipboard.setData(ClipboardData(text: tracking));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Nombor tracking disalin'), duration: Duration(seconds: 2)),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final status = _text(order['status']);
    final discount = double.tryParse((order['discount_amount'] ?? order['voucher_discount'] ?? order['discount_rm'] ?? 0).toString()) ?? 0;
    final subtotal = double.tryParse((order['subtotal_rm'] ?? order['subtotal'] ?? 0).toString()) ?? 0;
    final total = double.tryParse((order['total_rm'] ?? order['total'] ?? 0).toString()) ?? 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: const Color(0xFF11182B), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const CircleAvatar(backgroundColor: Color(0x1AFFB000), child: Icon(Icons.shopping_bag_rounded, color: Color(0xFFFFB000))),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_text(order['product_name']), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 4),
            Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 2,
              children: [
                Text('Tracking: ${_text(order['tracking_number'])}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                IconButton(
                  tooltip: 'Salin tracking',
                  visualDensity: VisualDensity.compact,
                  constraints: const BoxConstraints(minWidth: 30, minHeight: 30),
                  padding: EdgeInsets.zero,
                  onPressed: () => _copyTracking(_text(order['tracking_number'])),
                  icon: const Icon(Icons.copy_rounded, size: 14, color: Color(0xFFFFC857)),
                ),
              ],
            ),
          ])),
          Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: _statusColor(status).withValues(alpha: .12), borderRadius: BorderRadius.circular(20)), child: Text(status.toUpperCase(), style: TextStyle(color: _statusColor(status), fontSize: 9, fontWeight: FontWeight.w900))),
        ]),
        const SizedBox(height: 13),
        _detail('ID Game', _text(order['game_user_id'])),
        _detail('Kuantiti', _text(order['quantity'])),
        _detail('Tarikh pembelian', _formatDate(order['created_at'])),
        if (subtotal > 0) _detail('Subtotal', _money(subtotal)),
        if (discount > 0) _detail('Diskaun voucher', '- ${_money(discount)}', valueColor: const Color(0xFF57D69A)),
        const Divider(color: Colors.white12, height: 18),
        _detail('Jumlah dibayar', _money(total), valueColor: const Color(0xFFFFD166), bold: true),
      ]),
    );
  }

  Widget _detail(String label, String value, {Color valueColor = Colors.white70, bool bold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(children: [Expanded(child: Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11))), const SizedBox(width: 8), Flexible(child: Text(value, textAlign: TextAlign.right, style: TextStyle(color: valueColor, fontSize: 11, fontWeight: bold ? FontWeight.w900 : FontWeight.w600)))],),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF070B19),
    appBar: AppBar(automaticallyImplyLeading: false, backgroundColor: const Color(0xFF070B19), foregroundColor: Colors.white, leading: IconButton(tooltip: 'Kembali', icon: const Icon(Icons.arrow_back_rounded), onPressed: () { if (Navigator.of(context).canPop()) Navigator.of(context).pop(); }), title: const Text('SEJARAH PEMBELIAN SHOP', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)), actions: [IconButton(onPressed: loading ? null : _loadOrders, icon: const Icon(Icons.refresh_rounded))]),
    body: loading ? const SkeletonLoading(type: SkeletonType.history) : errorMessage != null ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(errorMessage!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)), const SizedBox(height: 12), ElevatedButton(onPressed: _loadOrders, child: const Text('Cuba lagi'))]))) : orders.isEmpty ? RefreshIndicator(onRefresh: _loadOrders, child: ListView(physics: const AlwaysScrollableScrollPhysics(), children: const [SizedBox(height: 150), Icon(Icons.receipt_long_rounded, size: 54, color: Colors.white24), SizedBox(height: 12), Center(child: Text('Belum ada pembelian shop.', style: TextStyle(color: Colors.white60))) ])) : RefreshIndicator(onRefresh: _loadOrders, child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.all(14), children: [Text('${orders.length} rekod pembelian', style: const TextStyle(color: Colors.white54, fontSize: 11)), const SizedBox(height: 12), ...orders.map(_orderCard)])),
  );
}
