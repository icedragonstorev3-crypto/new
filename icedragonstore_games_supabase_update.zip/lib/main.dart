import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'config/supabase_config.dart';
import 'pages/history_page.dart';
import 'pages/shop_page.dart';
import 'pages/wheel_page.dart';
import 'pages/wallet_page.dart';
import 'widgets/app_bottom_nav.dart';

import 'widgets/top_toast.dart';
import 'services/safe_cache_service.dart';
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SupabaseConfig.initialize();

  runApp(const IceDragonStoreApp());
}

class IceDragonStoreApp extends StatelessWidget {
  const IceDragonStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ICEDRAGONSTORE',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070A18),
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFFB000),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  bool loggedIn = false;
  bool guestMode = false;
  Map<String, dynamic>? profile;
  String? errorMessage;

  final client = SupabaseConfig.client;

  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    if (!mounted) return;

    setState(() {
      loading = true;
      errorMessage = null;
    });

    try {
      final session = client.auth.currentSession;

      if (session == null) {
        if (!mounted) return;

        setState(() {
          loggedIn = false;
          profile = null;
          loading = false;
        });

        return;
      }

      await _loadProfile();

      if (!mounted) return;

      setState(() {
        loggedIn = true;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        loggedIn = false;
        profile = null;
        loading = false;
        errorMessage = _cleanError(e);
      });
    }
  }

  Future<void> _loadProfile() async {
    final linkResponse = await client.rpc('link_my_auth_account');

    final linkData = linkResponse;

    if (linkData is Map && linkData['success'] == false) {
      throw Exception(linkData['message'] ?? 'Akaun Auth belum dipautkan.');
    }

    final profileResponse = await client.rpc('get_my_profile');

    if (profileResponse is! Map) {
      throw Exception('Profil tidak dijumpai.');
    }

    if (profileResponse['success'] == false) {
      throw Exception(
        profileResponse['message'] ?? 'Profil tidak berjaya dimuatkan.',
      );
    }

    final banned = profileResponse['is_banned'] == true;

    if (banned) {
      await SafeCacheService.instance.clearUser(client.auth.currentUser?.id ?? '');
      await client.auth.signOut();

      throw Exception(
        profileResponse['ban_reason'] ?? 'Akaun anda telah disekat.',
      );
    }

    profile = Map<String, dynamic>.from(profileResponse);
  }

  Future<void> _logout() async {
    try {
      await SafeCacheService.instance.clearUser(client.auth.currentUser?.id ?? '');
      await client.auth.signOut();
    } catch (_) {}

    if (!mounted) return;

    setState(() {
      loggedIn = false;
      profile = null;
    });
  }

  String _cleanError(Object error) {
    final text = error.toString();

    if (text.startsWith('Exception: ')) {
      return text.substring(11);
    }

    return text;
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const SplashPage();
    }

    if (loggedIn && profile != null) {
      return HomePage(profile: profile!, onLogout: _logout);
    }

    if (guestMode) {
      return HomePage(
        profile: const {'username': 'Tetamu', 'email': '', 'rm_balance': 0},
        onLogout: () async {
          if (mounted) setState(() => guestMode = false);
        },
        isGuest: true,
      );
    }

    return LoginPage(
      errorMessage: errorMessage,
      onLoginSuccess: _checkSession,
      onGuestMode: () { if (mounted) setState(() => guestMode = true); },
    );
  }
}

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF080B1C), Color(0xFF10162B)],
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppLogo(size: 82),
              SizedBox(height: 24),
              Text(
                'ICEDRAGONSTORE',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Memuatkan...',
                style: TextStyle(color: Colors.white60, fontSize: 14),
              ),
              SizedBox(height: 25),
              SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  color: Color(0xFFFFB000),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  final String? errorMessage;
  final Future<void> Function() onLoginSuccess;
  final VoidCallback onGuestMode;

  const LoginPage({
    super.key,
    required this.errorMessage,
    required this.onLoginSuccess,
    required this.onGuestMode,
  });

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  bool loading = false;
  bool obscurePassword = true;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final email = emailController.text.trim().toLowerCase();

    final password = passwordController.text;

    if (email.isEmpty) {
      _showMessage('Sila masukkan e-mel.', error: true);
      return;
    }

    if (!email.contains('@')) {
      _showMessage('Sila masukkan alamat e-mel yang sah.', error: true);
      return;
    }

    if (password.isEmpty) {
      _showMessage('Sila masukkan kata laluan.', error: true);
      return;
    }

    FocusScope.of(context).unfocus();

    setState(() {
      loading = true;
    });

    try {
      final client = SupabaseConfig.client;

      final response = await client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.session == null) {
        throw Exception('Sesi Supabase Auth tidak berjaya diwujudkan.');
      }

      await widget.onLoginSuccess();

      if (!mounted) return;

      _showMessage('Log masuk berjaya.', error: false);
    } catch (e) {
      if (!mounted) return;

      _showMessage(_cleanError(e), error: true);
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  String _cleanError(Object error) {
    final text = error.toString();

    if (text.startsWith('Exception: ')) {
      return text.substring(11);
    }

    if (text.contains('Invalid login credentials')) {
      return 'E-mel atau kata laluan tidak sah.';
    }

    if (text.contains('Email not confirmed')) {
      return 'E-mel akaun belum disahkan.';
    }

    return text;
  }

  void _showMessage(String message, {required bool error}) {
    TopToast.show(context, message, error: error);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF070A18), Color(0xFF0D1326), Color(0xFF070A18)],
            ),
          ),
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Column(
                  children: [
                    const AppLogo(size: 82),

                    const SizedBox(height: 20),

                    const Text(
                      'ICEDRAGONSTORE',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 27,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),

                    const SizedBox(height: 7),

                    const Text(
                      'LOG MASUK AKAUN',
                      style: TextStyle(
                        color: Color(0xFFFFB000),
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      ),
                    ),

                    const SizedBox(height: 30),

                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: const Color(0xFF11182B),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: .08),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: .3),
                            blurRadius: 30,
                            offset: const Offset(0, 15),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'E-mel',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: Colors.white70,
                            ),
                          ),

                          const SizedBox(height: 8),

                          _input(
                            controller: emailController,
                            hint: 'Masukkan e-mel anda',
                            icon: Icons.email_outlined,
                            keyboardType: TextInputType.emailAddress,
                          ),

                          const SizedBox(height: 18),

                          const Text(
                            'Kata Laluan',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: Colors.white70,
                            ),
                          ),

                          const SizedBox(height: 8),

                          _input(
                            controller: passwordController,
                            hint: 'Masukkan kata laluan',
                            icon: Icons.lock_outline,
                            obscureText: obscurePassword,
                            suffix: IconButton(
                              onPressed: () {
                                setState(() {
                                  obscurePassword = !obscurePassword;
                                });
                              },
                              icon: Icon(
                                obscurePassword
                                    ? Icons.visibility_outlined
                                    : Icons.visibility_off_outlined,
                                color: Colors.white54,
                              ),
                            ),
                            onSubmitted: (_) => _login(),
                          ),

                          const SizedBox(height: 24),

                          SizedBox(
                            width: double.infinity,
                            height: 54,
                            child: ElevatedButton(
                              onPressed: loading ? null : _login,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFFA800),
                                foregroundColor: const Color(0xFF17120A),
                                disabledBackgroundColor: const Color(
                                  0xFF6D5A2E,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                elevation: 0,
                              ),
                              child: loading
                                  ? const SizedBox(
                                      width: 24,
                                      height: 24,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2.5,
                                        color: Colors.black,
                                      ),
                                    )
                                  : const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.login_rounded, size: 22),
                                        SizedBox(width: 10),
                                        Text(
                                          'LOG MASUK',
                                          style: TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontSize: 15,
                                            letterSpacing: .5,
                                          ),
                                        ),
                                      ],
                                    ),
                            ),
                          ),

                          const SizedBox(height: 18),

                          if (widget.errorMessage != null)
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.red.withValues(alpha: .10),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: Colors.red.withValues(alpha: .25),
                                ),
                              ),
                              child: Text(
                                widget.errorMessage!,
                                style: const TextStyle(
                                  color: Colors.redAccent,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 14),
                    TextButton.icon(
                      onPressed: widget.onGuestMode,
                      icon: const Icon(Icons.visibility_outlined),
                      label: const Text('LIHAT SEBAGAI TETAMU'),
                      style: TextButton.styleFrom(
                        foregroundColor: const Color(0xFFFFB000),
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'ICEDRAGONSTORE • Flutter APK',
                      style: TextStyle(color: Colors.white30, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _input({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscureText = false,
    TextInputType? keyboardType,
    Widget? suffix,
    ValueChanged<String>? onSubmitted,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      onSubmitted: onSubmitted,
      style: const TextStyle(color: Colors.white, fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white30, fontSize: 13),
        prefixIcon: Icon(icon, color: const Color(0xFFFFB000)),
        suffixIcon: suffix,
        filled: true,
        fillColor: const Color(0xFF080D1C),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 17,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withValues(alpha: .06)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withValues(alpha: .07)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFFFB000), width: 1.4),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final Map<String, dynamic> profile;
  final Future<void> Function() onLogout;
  final bool isGuest;

  const HomePage({super.key, required this.profile, required this.onLogout, this.isGuest = false});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final SupabaseClient _client = SupabaseConfig.client;
  double? _rmBalance;
  bool _balanceLoading = true;
  bool _gamesLoading = true;
  List<Map<String, dynamic>> _games = [];

  @override
  void initState() {
    super.initState();
    _loadRmBalance();
    _loadGames();
  }

  Future<void> _loadGames() async {
    try {
      final response = await _client.from('game_catalog')
          .select('id,game_code,name,title,description,banner_url,icon_url,position_index,is_active')
          .eq('is_active', true).order('position_index', ascending: true);
      final rows = (response as List).whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row)).toList();
      if (mounted) setState(() { _games = rows; _gamesLoading = false; });
    } catch (_) {
      if (mounted) setState(() { _games = []; _gamesLoading = false; });
    }
  }

  Future<void> _loadRmBalance() async {
    try {
      // RM ialah mata wang berasingan daripada ICE CASH.
      final result = await _client.rpc('rm_wallet_my_balance');
      dynamic rawBalance;

      if (result is Map) {
        rawBalance = result['balance'] ?? result['rm_balance'];
      } else if (result is num || result is String) {
        rawBalance = result;
      }

      final value = rawBalance is num
          ? rawBalance.toDouble()
          : double.tryParse(rawBalance?.toString() ?? '');

      if (mounted && value != null) {
        setState(() {
          _rmBalance = value;
          _balanceLoading = false;
        });
        return;
      }
    } catch (_) {
      // Jika RPC gagal, hanya gunakan rm_balance daripada profil, bukan ICE CASH.
    }

    if (mounted) setState(() => _balanceLoading = false);
  }

  void _requireLogin(BuildContext context) {
    if (!widget.isGuest) return;
    TopToast.show(context, 'Log masuk diperlukan untuk menggunakan fungsi ini.');
  }

  @override
  Widget build(BuildContext context) {
    final profile = widget.profile;
    final onLogout = widget.onLogout;
    final username = profile['username']?.toString();
    final email = profile['email']?.toString();
    final displayName = widget.isGuest ? 'Tetamu' : ((username != null && username.isNotEmpty) ? username : (email ?? 'Pengguna'));

    return Scaffold(
      bottomNavigationBar: const AppBottomNav(currentIndex: 0),
      appBar: AppBar(
        backgroundColor: const Color(0xFF080B18),
        elevation: 0,
        title: const Text(
          'ICEDRAGONSTORE',
          style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1),
        ),
        leading: Builder(
          builder: (drawerContext) => IconButton(
            tooltip: 'Buka menu',
            icon: const Icon(Icons.menu_rounded, color: Color(0xFFFFB000)),
            onPressed: () => Scaffold.of(drawerContext).openDrawer(),
          ),
        ),
        actions: [notificationAction(context)],
      ),
      drawer: Drawer(
        backgroundColor: const Color(0xFF0B1020),
        child: SafeArea(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF171E35), Color(0xFF10162A)],
                  ),
                  border: Border(bottom: BorderSide(color: Colors.white12)),
                ),
                child: Row(
                  children: [
                    const AppLogo(size: 52),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'ICEDRAGONSTORE',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              letterSpacing: .5,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            displayName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white60),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'MENU',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: .48),
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ),
              _drawerItem(
                context,
                icon: Icons.casino_outlined,
                title: 'Roda Impian',
                subtitle: 'Putar roda & tebus reward',
                onTap: () => _openPage(context, const WheelPage()),
              ),
              _drawerItem(
                context,
                icon: Icons.receipt_long_outlined,
                title: 'History',
                subtitle: 'Lihat sejarah pembelian',
                onTap: () => _openPage(context, const HistoryPage()),
              ),
              _drawerItem(
                context,
                icon: Icons.person_outline_rounded,
                title: 'Profile',
                subtitle: 'Urus akaun anda',
                onTap: () {
                  Navigator.of(context).pop();
                  TopToast.show(context, 'Halaman Profile akan dibina selepas ini.');
                },
              ),
              const Spacer(),
              const Divider(color: Colors.white12, height: 1),
              ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 22,
                  vertical: 8,
                ),
                leading: const Icon(
                  Icons.logout_rounded,
                  color: Colors.redAccent,
                ),
                title: const Text(
                  'Log Keluar',
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                subtitle: const Text(
                  'Keluar daripada akaun anda',
                  style: TextStyle(color: Colors.white54, fontSize: 12),
                ),
                onTap: () async {
                  Navigator.of(context).pop();
                  await onLogout();
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Kotak profil pengguna — berasingan daripada banner slide.
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF171E35), Color(0xFF10162A)],
                  ),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: Colors.white12),
                ),
                child: Row(
                  children: [
                    const AppLogo(size: 58),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'SELAMAT DATANG',
                            style: TextStyle(
                              color: Color(0xFFFFB000),
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            displayName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 21,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          if (email != null && email.isNotEmpty)
                            Text(
                              email,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white54,
                                fontSize: 12,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              if (widget.isGuest) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: const Color(0xFF302713), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFFFB000).withValues(alpha: .35))),
                  child: const Text('Mod tetamu: anda boleh melihat Home dan promosi. Log masuk diperlukan untuk dompet, pembelian dan sejarah pesanan.', style: TextStyle(color: Colors.white70, fontSize: 12)),
                ),
              ],
              const SizedBox(height: 16),
              // Ringkasan akaun: nilai hanya dipaparkan jika dibekalkan oleh profil.
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _summaryCard(
                      icon: Icons.account_balance_wallet_outlined,
                      label: 'Baki RM',
                      value: widget.isGuest ? 'Log masuk' : (_balanceLoading ? 'Memuat...' : _formatBalance(_rmBalance ?? profile['rm_balance'])),
                      onTap: () { if (widget.isGuest) { _requireLogin(context); } else { _openPage(context, const WalletPage()); } },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _summaryCard(
                      icon: Icons.shopping_bag_outlined,
                      label: 'Pesanan',
                      value: 'Lihat History',
                      compact: true,
                      onTap: () { if (widget.isGuest) { _requireLogin(context); } else { _openPage(context, const HistoryPage()); } },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              _sectionHeading('Promosi Pilihan', trailing: 'PROMOSI'),
              const SizedBox(height: 12),
              const BannerSlideWidget(),
              const SizedBox(height: 24),
              _sectionHeading('Games Popular', trailing: 'SEMUA GAME'),
              const SizedBox(height: 12),
              if (_gamesLoading)
                const Padding(padding: EdgeInsets.all(22), child: Center(child: CircularProgressIndicator(color: Color(0xFFFFB000))))
              else if (_games.isEmpty)
                Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF141C31), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white10)), child: const Text('Belum ada game aktif. Admin boleh tambah game melalui adminproduk.html.', style: TextStyle(color: Colors.white60)))
              else
                LayoutBuilder(
                  builder: (context, constraints) {
                    final columns = constraints.maxWidth >= 520 ? 3 : 2;
                    return GridView.builder(
                      shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                      itemCount: _games.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: columns, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: columns == 3 ? .86 : .92),
                      itemBuilder: (context, index) {
                        final game = _games[index];
                        final gameCode = (game['game_code'] ?? '').toString();
                        final image = (game['banner_url'] ?? game['icon_url'] ?? '').toString();
                        return _gameCard(
                          name: (game['name'] ?? gameCode).toString(),
                          subtitle: (game['description'] ?? 'Lihat senarai harga').toString(),
                          icon: Icons.sports_esports_rounded,
                          accent: const Color(0xFFFFB000),
                          imageUrl: image,
                          onTap: () { _openPage(context, ShopPage(gameCode: gameCode, gameName: (game['name'] ?? game['title'] ?? gameCode).toString(), gameDescription: (game['description'] ?? '').toString())); },
                        );
                      },
                    );
                  },
                ),
              const SizedBox(height: 24),

            ],
          ),
        ),
      ),
    );
  }

  static const List<Map<String, dynamic>> _popularGames = [
    {
      'name': 'Mobile Legends',
      'subtitle': 'Diamonds',
      'icon': Icons.diamond_outlined,
      'accent': Color(0xFF55B7FF),
    },
    {
      'name': 'Free Fire',
      'subtitle': 'Diamonds',
      'icon': Icons.local_fire_department_rounded,
      'accent': Color(0xFFFF7043),
    },
    {
      'name': 'PUBG Mobile',
      'subtitle': 'UC',
      'icon': Icons.military_tech_outlined,
      'accent': Color(0xFFFFC857),
    },
    {
      'name': 'Genshin Impact',
      'subtitle': 'Genesis Crystal',
      'icon': Icons.auto_awesome_rounded,
      'accent': Color(0xFFB39DFF),
    },
    {
      'name': 'Call of Duty Mobile',
      'subtitle': 'CP',
      'icon': Icons.shield_outlined,
      'accent': Color(0xFFB8C6D9),
    },
    {
      'name': 'Valorant',
      'subtitle': 'Points',
      'icon': Icons.bolt_rounded,
      'accent': Color(0xFFFF657A),
    },
  ];

  String _formatBalance(dynamic value) {
    if (value == null || value.toString().trim().isEmpty) return 'RM 0.00';
    final number = num.tryParse(value.toString());
    if (number == null) return 'RM 0.00';
    return 'RM ${number.toStringAsFixed(2)}';
  }

  Widget _sectionHeading(String title, {String? trailing}) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          ),
        ),
        if (trailing != null)
          Text(
            trailing,
            style: const TextStyle(
              color: Color(0xFFFFB000),
              fontSize: 10,
              fontWeight: FontWeight.w900,
              letterSpacing: .5,
            ),
          ),
      ],
    );
  }

  Widget _summaryCard({
    required IconData icon,
    required String label,
    required String value,
    bool compact = false,
    VoidCallback? onTap,
  }) {
    return Material(
      color: const Color(0xFF141C31),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: const Color(0xFFFFB000), size: 25),
              const SizedBox(height: 10),
              Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
              const SizedBox(height: 5),
              Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: compact ? 14 : 19,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _quickAction({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Material(
      color: const Color(0xFF182239),
      borderRadius: BorderRadius.circular(15),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 3),
          child: Column(
            children: [
              Icon(icon, color: const Color(0xFFFFB000), size: 25),
              const SizedBox(height: 7),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _gameCard({
    required String name,
    required String subtitle,
    required IconData icon,
    required Color accent,
    String imageUrl = '',
    required VoidCallback onTap,
  }) {
    return Material(
      color: const Color(0xFF141C31),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        accent.withValues(alpha: .28),
                        const Color(0xFF0C1224),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: imageUrl.trim().isNotEmpty
                      ? ClipRRect(borderRadius: BorderRadius.circular(13), child: Image.network(imageUrl, fit: BoxFit.cover, width: double.infinity, errorBuilder: (_, __, ___) => Icon(icon, size: 42, color: accent)))
                      : Icon(icon, size: 42, color: accent),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white60, fontSize: 10),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'LIHAT PAKEJ',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Color(0xFFFFB000),
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_forward_rounded, size: 14, color: accent),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _featureTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: const Color(0xFF141C31),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white10),
          ),
          child: Row(
            children: [
              Icon(icon, color: const Color(0xFFFFB000), size: 26),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 10)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showComingSoon(String feature) {
    TopToast.show(
      context,
      '$feature akan diaktifkan selepas sistem database/admin disediakan.',
    );
  }

  Widget _drawerItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 3),
      leading: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: const Color(0xFFFFB000).withValues(alpha: .12),
          borderRadius: BorderRadius.circular(13),
        ),
        child: Icon(icon, color: const Color(0xFFFFB000)),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text(
        subtitle,
        style: const TextStyle(color: Colors.white54, fontSize: 11),
      ),
      trailing: const Icon(Icons.chevron_right_rounded, color: Colors.white38),
      onTap: onTap,
    );
  }

  void _openPage(BuildContext context, Widget page) {
    // Tutup drawer sahaja jika ia sedang terbuka; jangan pop route Home.
    Scaffold.maybeOf(context)?.closeDrawer();

    // Kekalkan Home dalam navigation stack supaya butang Home bawah
    // boleh kembali ke halaman utama selepas membuka History/Wheel.
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }
}


/// Slider banner yang mengambil data daripada jadual Supabase `banner_slides`.
/// Hanya banner aktif dipaparkan, mengikut `position_index`.
class BannerSlideWidget extends StatefulWidget {
  const BannerSlideWidget({super.key});

  @override
  State<BannerSlideWidget> createState() => _BannerSlideWidgetState();
}

class _BannerSlideWidgetState extends State<BannerSlideWidget> {
  final PageController _pageController = PageController();
  List<Map<String, dynamic>> _slides = [];
  Timer? _slideTimer;
  int _currentIndex = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadSlides();
  }

  Future<void> _loadSlides() async {
    try {
      final response = await SupabaseConfig.client
          .from('banner_slides')
          .select('id,title,image_url,is_clickable,target_url,position_index,is_active')
          .eq('is_active', true)
          .order('position_index', ascending: true);
      final rows = (response as List)
          .whereType<Map<String, dynamic>>()
          .where((slide) => (slide['image_url']?.toString().trim().isNotEmpty ?? false))
          .toList();
      if (!mounted) return;
      setState(() {
        _slides = rows;
        _loading = false;
      });
      _startAutoSlide();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
      });
    }
  }

  void _startAutoSlide() {
    _slideTimer?.cancel();
    if (_slides.length < 2) return;
    _slideTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || !_pageController.hasClients || _slides.isEmpty) return;
      final next = (_currentIndex + 1) % _slides.length;
      _pageController.animateToPage(
        next,
        duration: const Duration(milliseconds: 650),
        curve: Curves.easeInOut,
      );
    });
  }

  Future<void> _openSlideLink(Map<String, dynamic> slide) async {
    if (slide['is_clickable'] != true) return;
    final rawUrl = slide['target_url']?.toString().trim() ?? '';
    final uri = Uri.tryParse(rawUrl);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) {
      if (!mounted) return;
      TopToast.show(context, 'Pautan banner tidak sah.', error: true);
      return;
    }
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        TopToast.show(context, 'Pautan tidak dapat dibuka.', error: true);
      }
    } catch (_) {
      if (!mounted) return;
      TopToast.show(context, 'Pautan tidak dapat dibuka pada peranti ini.', error: true);
    }
  }

  @override
  void dispose() {
    _slideTimer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Container(
        height: 132,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .04),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white10),
        ),
        child: const Center(
          child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFB000)),
          ),
        ),
      );
    }
    if (_slides.isEmpty) {
      // Ruang banner disembunyikan jika admin belum menambah slide.
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFFFB000).withValues(alpha: .28)),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFFB000).withValues(alpha: .07),
                blurRadius: 18,
                spreadRadius: 1,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(19),
            child: AspectRatio(
              aspectRatio: 16 / 9,
            child: PageView.builder(
              controller: _pageController,
              itemCount: _slides.length,
              onPageChanged: (index) => setState(() => _currentIndex = index),
              itemBuilder: (context, index) {
                final slide = _slides[index];
                final imageUrl = slide['image_url'].toString();
                return Material(
                  color: const Color(0xFF11182A),
                  child: InkWell(
                    onTap: () => _openSlideLink(slide),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.network(
                          imageUrl,
                          fit: BoxFit.cover,
                          loadingBuilder: (context, child, progress) => progress == null
                              ? child
                              : Container(
                                  color: const Color(0xFF11182A),
                                  alignment: Alignment.center,
                                  child: const CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Color(0xFFFFB000),
                                  ),
                                ),
                          errorBuilder: (context, error, stackTrace) => Container(
                            color: const Color(0xFF11182A),
                            alignment: Alignment.center,
                            child: const Icon(Icons.broken_image_outlined,
                                color: Colors.white38, size: 32),
                          ),
                        ),
                        if (slide['is_clickable'] == true)
                          const Positioned(
                            right: 9,
                            bottom: 9,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                color: Color(0x99070A18),
                                borderRadius: BorderRadius.all(Radius.circular(20)),
                              ),
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.open_in_new_rounded, size: 12, color: Colors.white),
                                    SizedBox(width: 4),
                                    Text('BUKA', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: Colors.white)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        ),
        if (_slides.length > 1) ...[
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_slides.length, (index) {
              final active = index == _currentIndex;
              return GestureDetector(
                onTap: () => _pageController.animateToPage(
                  index,
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                ),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: active ? 22 : 7,
                  height: 7,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: active ? const Color(0xFFFFB000) : Colors.white24,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              );
            }),
          ),
        ],
      ],
    );
  }
}

class AppLogo extends StatelessWidget {
  final double size;

  const AppLogo({super.key, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFF302A21),
        borderRadius: BorderRadius.circular(size * .28),
        border: Border.all(
          color: const Color(0xFFFFB000).withValues(alpha: .45),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFFB000).withValues(alpha: .08),
            blurRadius: 20,
          ),
        ],
      ),
      child: Icon(
        Icons.ac_unit_rounded,
        color: const Color(0xFFFFB000),
        size: size * .55,
      ),
    );
  }
}
