
import 'dart:async';
import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(
  RemoteMessage message,
) async {
  await Firebase.initializeApp();
}

class PushNotificationService {
  PushNotificationService._();

  static final PushNotificationService instance =
      PushNotificationService._();

  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static const AndroidNotificationChannel _channel =
      AndroidNotificationChannel(
    'icedragon_manual_push',
    'ICEDRAGONSTORE Notifications',
    description: 'Notifikasi rasmi daripada pentadbir ICEDRAGONSTORE.',
    importance: Importance.high,
  );

  StreamSubscription<RemoteMessage>? _foregroundSubscription;
  StreamSubscription<RemoteMessage>? _openedSubscription;
  StreamSubscription<String>? _tokenRefreshSubscription;

  static const String _registrationFunction = 'register-device-token';

  Future<void> initialize() async {
    await Firebase.initializeApp();

    FirebaseMessaging.onBackgroundMessage(
      firebaseMessagingBackgroundHandler,
    );

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const initializationSettings = InitializationSettings(
      android: androidSettings,
    );

    await _localNotifications.initialize(
      settings: initializationSettings,
      onDidReceiveNotificationResponse: (response) {
        // Navigasi boleh disambungkan kemudian.
      },
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_channel);

    final messaging = FirebaseMessaging.instance;

    // Minta kebenaran sebelum mendaftar token.
    final permission = await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (permission.authorizationStatus ==
        AuthorizationStatus.denied) {
      debugPrint('FCM: Kebenaran notifikasi ditolak.');
    } else {
      await _registerCurrentToken(messaging);
    }

    // Daftar semula apabila Firebase menukar token.
    await _tokenRefreshSubscription?.cancel();
    _tokenRefreshSubscription = messaging.onTokenRefresh.listen(
      (token) {
        _registerToken(token);
      },
      onError: (Object error) {
        debugPrint('FCM token refresh gagal: $error');
      },
    );

    await _foregroundSubscription?.cancel();
    await _openedSubscription?.cancel();

    _foregroundSubscription =
        FirebaseMessaging.onMessage.listen(
      _showForegroundNotification,
    );

    _openedSubscription =
        FirebaseMessaging.onMessageOpenedApp.listen(
      _handleNotificationTap,
    );

    final initialMessage = await messaging.getInitialMessage();

    if (initialMessage != null) {
      _handleNotificationTap(initialMessage);
    }
  }

  Future<void> _registerCurrentToken(
    FirebaseMessaging messaging,
  ) async {
    try {
      final token = await messaging.getToken();

      if (token != null && token.isNotEmpty) {
        await _registerToken(token);
      }
    } catch (error) {
      debugPrint('FCM: Gagal mendapatkan token: $error');
    }
  }

  Future<void> _registerToken(String token) async {
    try {
      final response =
          await Supabase.instance.client.functions.invoke(
        _registrationFunction,
        body: {
          'token': token,
          'platform': defaultTargetPlatform == TargetPlatform.iOS
              ? 'ios'
              : 'android',
        },
      );

      if (response.status >= 200 && response.status < 300) {
        debugPrint('FCM: Pendaftaran token berjaya.');
      } else {
        debugPrint(
          'FCM: Pendaftaran gagal, status ${response.status}.',
        );
      }
    } catch (error) {
      debugPrint('FCM: Pendaftaran token gagal: $error');
    }
  }

  Future<void> _showForegroundNotification(
    RemoteMessage message,
  ) async {
    final notification = message.notification;

    if (notification == null) return;

    final payload = jsonEncode(message.data);

    await _localNotifications.show(
      id: message.messageId?.hashCode ??
          DateTime.now().millisecondsSinceEpoch,
      title: notification.title ?? 'ICEDRAGONSTORE',
      body: notification.body ?? '',
      notificationDetails: const NotificationDetails(
        android: AndroidNotificationDetails(
          'icedragon_manual_push',
          'ICEDRAGONSTORE Notifications',
          channelDescription:
              'Notifikasi rasmi daripada pentadbir ICEDRAGONSTORE.',
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
      payload: payload,
    );
  }

  void _handleNotificationTap(RemoteMessage message) {
    // Navigasi boleh ditambah selepas struktur halaman diperiksa.
  }

  Future<String?> getToken() {
    return FirebaseMessaging.instance.getToken();
  }

  Future<void> dispose() async {
    await _foregroundSubscription?.cancel();
    await _openedSubscription?.cancel();
    await _tokenRefreshSubscription?.cancel();
  }
}

