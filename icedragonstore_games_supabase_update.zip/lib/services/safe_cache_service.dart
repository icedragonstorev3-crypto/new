import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Encrypted, per-user display cache. Never use cached values to authorize actions.
class SafeCacheService {
  SafeCacheService._();
  static final SafeCacheService instance = SafeCacheService._();
  static const FlutterSecureStorage _storage = FlutterSecureStorage();
  static const Duration defaultTtl = Duration(hours: 24);

  String _key(String userId, String bucket) {
    final safeUser = userId.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
    final safeBucket = bucket.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
    return 'safe_cache_v1_${safeUser}_$safeBucket';
  }

  Future<void> writeList({required String userId, required String bucket,
      required List<Map<String, dynamic>> data,
      Duration ttl = defaultTtl}) async {
    if (userId.isEmpty) return;
    final envelope = <String, dynamic>{
      'version': 1,
      'expiresAt': DateTime.now().add(ttl).toUtc().millisecondsSinceEpoch,
      'data': data,
    };
    await _storage.write(key: _key(userId, bucket), value: jsonEncode(envelope));
  }

  Future<List<Map<String, dynamic>>?> readList({required String userId,
      required String bucket}) async {
    if (userId.isEmpty) return null;
    try {
      final raw = await _storage.read(key: _key(userId, bucket));
      if (raw == null) return null;
      final envelope = jsonDecode(raw);
      if (envelope is! Map || envelope['version'] != 1 ||
          envelope['expiresAt'] is! num || envelope['data'] is! List) {
        await _storage.delete(key: _key(userId, bucket));
        return null;
      }
      if (DateTime.now().toUtc().millisecondsSinceEpoch >=
          (envelope['expiresAt'] as num).toInt()) {
        await _storage.delete(key: _key(userId, bucket));
        return null;
      }
      return (envelope['data'] as List)
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    } catch (_) {
      return null;
    }
  }

  Future<void> clearUser(String userId) async {
    if (userId.isEmpty) return;
    for (final bucket in const ['shop_products', 'wheel_display', 'history_display']) {
      await _storage.delete(key: _key(userId, bucket));
    }
  }
}
