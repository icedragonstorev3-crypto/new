-- ICEDRAGONSTORE: katalog game untuk Home, banner dan halaman senarai harga.
-- Migrasi ADDITIVE: tidak mengubah atau DROP jadual/fungsi sedia ada.
-- Jalankan selepas semak polisi admin public.is_admin_auth() wujud dan betul.

create table if not exists public.game_catalog (
  id uuid primary key default gen_random_uuid(),
  game_code text not null unique check (game_code ~ '^[A-Z0-9_]{2,80}$'),
  name text not null check (length(trim(name)) between 1 and 120),
  title text,
  description text,
  banner_url text,
  icon_url text,
  position_index integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists game_catalog_active_position_idx
  on public.game_catalog (is_active, position_index, name);

alter table public.game_catalog enable row level security;

-- Buang polisi bernama sama sahaja supaya skrip boleh dijalankan semula.
drop policy if exists game_catalog_public_read_active on public.game_catalog;
create policy game_catalog_public_read_active
  on public.game_catalog for select to anon, authenticated
  using (is_active = true);

drop policy if exists game_catalog_admin_read_all on public.game_catalog;
create policy game_catalog_admin_read_all
  on public.game_catalog for select to authenticated
  using ((select public.is_admin_auth()) is true);

drop policy if exists game_catalog_admin_insert on public.game_catalog;
create policy game_catalog_admin_insert
  on public.game_catalog for insert to authenticated
  with check ((select public.is_admin_auth()) is true);

drop policy if exists game_catalog_admin_update on public.game_catalog;
create policy game_catalog_admin_update
  on public.game_catalog for update to authenticated
  using ((select public.is_admin_auth()) is true)
  with check ((select public.is_admin_auth()) is true);

drop policy if exists game_catalog_admin_delete on public.game_catalog;
create policy game_catalog_admin_delete
  on public.game_catalog for delete to authenticated
  using ((select public.is_admin_auth()) is true);

grant select on public.game_catalog to anon, authenticated;
grant insert, update, delete on public.game_catalog to authenticated;

-- Pastikan kod game ini sama dengan products.game_code dalam RPC rm_shop_public_products.
-- Contoh data permulaan (pilihan):
-- insert into public.game_catalog(game_code,name,title,description,position_index,is_active)
-- values ('MOBILE_LEGENDS','Mobile Legends','Top Up Diamonds','Pilih pakej Diamonds Mobile Legends.',1,true)
-- on conflict (game_code) do nothing;
