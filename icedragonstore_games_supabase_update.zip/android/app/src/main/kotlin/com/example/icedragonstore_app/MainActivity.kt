package com.example.icedragonstore_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
